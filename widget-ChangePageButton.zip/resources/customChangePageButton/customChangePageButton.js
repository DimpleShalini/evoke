(function () {
  try {
    return angular.module('bonitasoft.ui.widgets');
  } catch(e) {
    return angular.module('bonitasoft.ui.widgets', []);
  }
})().directive('customChangePageButton', function() {
    return {
      controllerAs: 'ctrl',
      controller: function ChangePageButton($scope) {
   var reimbursementCount = $scope.properties.reimbursementCount;
   var decideFormFlag = $scope.properties.decideFormFlag;
    
    if(angular.isUndefined(reimbursementCount))
        reimbursementCount = 0 
    else
        reimbursementCount = parseInt(reimbursementCount);
        
     
    console.log('decideFormFlag '+decideFormFlag);
    
    $scope.changePage = function() {
          if (!angular.isNumber($scope.properties.pageId))
               throw 'ChangePageButton: "Page id" parameter not a number';
         var transferDetails = $scope.properties.transferDetails;    
         
        var reg = /^\(?([0-9]{3})\)?[-]?([0-9]{3})[-]?([0-9]{4})$/;  
      
        var isValid = reg.exec(transferDetails.requestorDataInput.employeePhoneNumber);  
        if (isValid) {
           console.log("phone number valid"); 
        }  else{
            console.log("phone number isn't  valid"); 
            return false;
        }  
           
       
        
         
         if(angular.equals("transfer",transferDetails.requestorDataInput.requestType)){ // transfer or enroll
             console.log('Transfer block Begin ');
             console.log('Before Increment pageId '+$scope.properties.pageId);
             console.log('reimbursementCount '+reimbursementCount);
             if(angular.equals("yes",decideFormFlag)){
                  console.log('--Form Decide Block Enter -------');
                  console.log('transferDetails '+JSON.stringify(transferDetails));
                  console.log('request type  '+transferDetails.requestorDataInput.requestType);
                  console.log('reimbursementFlag  '+transferDetails.requestorDataInput.reimbursement);
                  
               if ($scope.properties.pageAction == 'Next'){  
                     if(reimbursementCount>0 && angular.equals("true",transferDetails.requestorDataInput.reimbursement)){
                         $scope.properties.pageId++;  
                     }else{
                          $scope.properties.pageId =  $scope.properties.pageId + 2;
                     }
               }else{
                   // for back button
                   if(reimbursementCount>0 && angular.equals("true",transferDetails.requestorDataInput.reimbursement)){
                         $scope.properties.pageId--;  
                     }else{
                          $scope.properties.pageId =  $scope.properties.pageId - 2;
                     }
               }
                 console.log('After Increment pageId '+$scope.properties.pageId);
                console.log('--Form Decide Block End -------');
             }else{ // this block for from second screen means device aggrement/notitification
                console.log('--Continue screens  Block Enter -------');
                console.log('Before Increment pageId '+$scope.properties.pageId);
                 if ($scope.properties.pageAction == 'Next'){
                      $scope.properties.pageId++;  
                 }else{
                      $scope.properties.pageId--; 
                 }
                 console.log('After Increment pageId '+$scope.properties.pageId);
                 console.log('--Continue screens Block End -------');
             }
             console.log('Transfer block End ');
         }else{ // this block for enroll
           console.log('Enroll block Enter ');
            console.log('Before Increment pageId '+$scope.properties.pageId);
             if ($scope.properties.pageAction == 'Next'){
                  $scope.properties.pageId++;  
             }else{
                  $scope.properties.pageId--; 
             }
              console.log('After Increment pageId '+$scope.properties.pageId);
             console.log('Enroll block End ');
         }
         
         
        
       /* if ($scope.properties.pageAction == 'Next'){
            if(flag){
              $scope.properties.pageId++;  
            }else{
                $scope.properties.pageId = $scope.properties.pageId+2;
            }
        }
        else{
            if(flag){
              $scope.properties.pageId--;  
            }else{
                $scope.properties.pageId = $scope.properties.pageId-2;
            }
            $scope.properties.pageId --;
        }*/
    };
},
      template: '<div class="text-{{ properties.alignment }}">\n    <button\n        type="button"\n        ng-class="\'btn btn-\' + properties.buttonStyle"\n        ng-click="changePage()"\n        ng-disabled="properties.disabled">{{ properties.label | uiTranslate }}</button>\n</div>'
    };
  });
