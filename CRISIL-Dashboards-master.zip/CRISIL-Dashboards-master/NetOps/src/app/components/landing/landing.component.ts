import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { DatePipe } from '@angular/common';

import { SortDescriptor, State, CompositeFilterDescriptor } from '@progress/kendo-data-query';
import { GridDataResult, SelectAllCheckboxState, PageChangeEvent } from '@progress/kendo-angular-grid';
import { CookieService } from 'ngx-cookie-service';
import { TabsetComponent } from 'ngx-bootstrap/tabs';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { Observable, of, Subscription, timer} from 'rxjs';
import { debounceTime, distinctUntilChanged, switchMap, map, catchError, tap  } from 'rxjs/operators';
import { ToastrService } from 'ngx-toastr';

import { LoaderService } from '../../loader.service';
import { DataService } from '../../services/share.service';
import { DashboardService } from '../../services/dashboard.service';
import { ExcelServicesService } from '../../services/excel.service';
import { BulkuploadService } from '../../services/bulkupload.service';
import { BulkuploadSharedData } from '../../services/bulkUpload.sharedData.service';
import { stickyColumnDimensions, commonColumnDimensions } from './kendoGridStickyColumns';
import { CommentsModalComponent } from './coments-modal.component';
import * as XLSX from 'xlsx';
import * as FileSaver from 'file-saver';
const EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
const EXCEL_EXTENSION = '.xlsx';

@Component({
  selector: "landing-component",
  templateUrl: './landing.component.html',
  styleUrls: ['./landing.component.scss'],
  providers: [DatePipe]
})
export class LandingComponent implements OnInit, OnDestroy {
  @ViewChild('tabset', { static: true }) tabset: TabsetComponent;
  bsModalRef: BsModalRef;

  singleModuleSearch = {
    searchProductTypeText: '',
    searchInstituteText: '',
    searchBillingCompany: '',
    searchBillingCompanyContact: ''
  };
  public filter: CompositeFilterDescriptor;
  public state: State = {
    skip: 0,
    take: 10,
    sort: [{
      field: 'entity_name',
      dir: 'asc'
    }],
    filter: {
      logic: 'and',
      filters: []
    }
  };
  overviewPage = { page: 1, pageSize: 10 };
  public gridData: GridDataResult;
  public filteredData: any;
  public comment: string;
  public userRole: string;
  public userid: any;
  public gridShow: string = 'all';
  modalRef: BsModalRef;
  showCommonColumns: any = [];
  stickyCount: number;
  public productId: any;
  usrData: any;

  statuses = [
    { name: 'Allocated to Reviewer Team 1'},
    { name: 'Allocated to Team 1 Analyst' },
    { name: 'BD originated' },
    { name: 'Info req approved'},
    { name: 'Info req received'},
    { name: 'Mandate Created' },
    { name: 'Team 1 rejected' },
    { name: 'Team 2 Reviewer approved' }
  ];

  mandatesCounts = {
    totalMandateCount: 0,
    createdMandateCount: 0,
    orginatedMandateCount: 0,
    allocatedtoanalyst: 0,
    closedMandateCount: 0
  };

  mainColumnDimenstions = {
    mandate_id                : { sticky : true, checked : true },
    mandate_created_date      : { sticky : false, checked : true },
    case_login_date           : { sticky : false, checked : true },
    institution_name          : { sticky : true, checked : true },
    bd_name                   : { sticky : false, checked : true },
    entity_name               : { sticky : false, checked : true },
    case_current_status       : { sticky : false, checked : true },
    coordination_case_status  : { sticky : false, checked : true },
    workflow_status           : { sticky : false, checked : true },
    last_main_case_status_date: { sticky : false, checked : true },
    product                   : { sticky : false, checked : true },
    mandate_originated_date   : { sticky : false, checked : true },
    tl                        : { sticky : false, checked : true },
    analyst                   : { sticky : false, checked : true },
    tat                       : { sticky : false, checked : true },
    last_updated_date         : { sticky : false, checked : true },
    credit_exposure_by_bank   : { sticky : false, checked : true },
    order_id                  : { sticky : false, checked : false },
    sme_first_status          : { sticky : false, checked : false },
    lender                    : { sticky : false, checked : false }
  };
  datastring: any;

  stickyColumnDimensions: any = stickyColumnDimensions;
  commonColumnDimensions: any = commonColumnDimensions;

  public mySelection: number[] = [];
  public selectAllState: SelectAllCheckboxState = 'unchecked';
  excel = [];
  isChecked: boolean = false;
  currentColumnSelection: any = [];
  searchProductName: any;
  searchInstituteName: any;
  searchBillingComp: any;
  searchBillingCompContact: any;
  institutionId: any;
  workId: any;
  hasDeleteAccess: boolean = false;
  subscription: Subscription;
  companyContacts: any = [];
  products = [];

  constructor(
    private loaderService: LoaderService,
    private dashBoard: DashboardService,
    private datePip: DatePipe,
    private modalService: BsModalService,
    private excelService: ExcelServicesService,
    private bulkUploadService: BulkuploadService,
    private bulkUploadSharedData: BulkuploadSharedData,
    private router: Router,
    private toastr: ToastrService,
    private data: DataService,
    public cookieService: CookieService) {

  }

  ngOnInit() {
    this.getUserRole();
    this.getColumnDisplay();
    this.getAllMandatess();

    this.data.search.subscribe(searchFilter => {
      if (searchFilter.searchWord === '') {
        this.getAllMandatess();
      }
      if (searchFilter.searchWord) {
        this.globalSearchFilter(searchFilter);
      }
    });
    // this.subscription = timer(0, 20000).subscribe(_ => this.getMandatesCount());
  }

  ngOnDestroy() {
    // this.subscription.unsubscribe();
  }

  getUserRole() {
    const userName = this.cookieService.get('userName');
    this.dashBoard.checkUserRoles(userName).subscribe(
      data => {
        if (data['UserRoles']) {
          this.hasDeleteAccess =  data['UserRoles'].includes('Netops_Admin');
        }
      }
    );
  }

  updateCheckedOptions(options, event, type?, ind?) {
    if (type && type === 'sticky') {
      this.stickyColumnDimensions[ind].sticky = !this.stickyColumnDimensions[ind].sticky;
      this.stickyColumnDimensions[ind].checked = !this.stickyColumnDimensions[ind].checked;
      this.stickyColumnDimensions[ind].status = !this.stickyColumnDimensions[ind].status;
      if (this.stickyColumnDimensions[ind].checked) {
        if (this.commonColumnDimensions[ind].checked) {
          this.commonColumnDimensions[ind].checked = !this.commonColumnDimensions[ind].checked;
        }
        this.commonColumnDimensions[ind].disabled = true;
      } else {
        this.commonColumnDimensions[ind].disabled = false;
        this.commonColumnDimensions[ind].checked = false;
      }
      this.isSticky(this.stickyColumnDimensions[ind].sticky);
      this.checkColumnCount();
    } else {
      this.commonColumnDimensions[ind].checked = !this.commonColumnDimensions[
        ind
      ].checked;
      this.commonColumnDimensions[ind].status = !this.commonColumnDimensions[
        ind
      ].status;
      this.isSticky(this.stickyColumnDimensions[ind].sticky);
    }
  }

  checkColumnCount() {
    this.stickyCount = 0;
    this.stickyColumnDimensions.forEach(item => {
      if (item.checked) {
        this.stickyCount = this.stickyCount + 1;
      }
    });
    if (this.stickyCount >= 2) {
      this.stickyColumnDimensions.forEach(item => {
        if (!item.checked) {
          item.disabled = true;
        }
      });
    } else {
      this.stickyColumnDimensions.forEach(item => {
        if (!item.checked) {
          item.disabled = false;
        }
      });
    }
  }

  isSticky(col) {
    return true;
  }

  openModal(options, type, dataItem) {
    if (type === '') {
      this.dashBoard.getProducts().subscribe(
        result => {
          const products: any = result;
          this.products = products.map(data => data['PRODUCTNAME']);
        }
      );
    }
    if (type === 'delete') {
      if ( this.mySelection && this.mySelection.length < 1) {
        return;
      }
    }
    this.companyContacts = [];
    this.singleModuleSearch = {
      searchProductTypeText: '',
      searchInstituteText: '',
      searchBillingCompany: '',
      searchBillingCompanyContact: ''
    };
    setTimeout(() => {
      this.modalRef = this.modalService.show(options, { keyboard: false, ignoreBackdropClick: true });
    }, 400);
    if (type === 'configureColumns') {
      this.checkColumnCount();
    }
    if (type === 'cmnt') {
      this.workId = dataItem.workflow_id;
      this.getComments();
    }
  }

  public filterChange(filter: CompositeFilterDescriptor): void {
    this.overviewPage.page = 1;
    this.overviewPage.pageSize = 10;
    this.state.skip = 0;
    this.state.take = 10;
    this.state.filter = filter;
    this.getAllMandatess();
  }

  public sortChange(sort: SortDescriptor[]): void {
    this.state.sort = sort;
    this.getAllMandatess();
  }

  public pageChange({ skip, take }: PageChangeEvent): void {
    this.state.skip = skip;
    this.state.take = take;
    this.overviewPage.page = skip / 10 + 1;
    this.overviewPage.pageSize = take;
    this.getAllMandatess();
  }

  getAllMandatess() {
    this.loaderService.isLoading.next(true);
    this.getMandatesCount();

    if (this.gridShow === 'all') {
      this.dashBoard.getAllMandatesWithFilters(this.state.filter, this.overviewPage, this.state.sort)
        .subscribe(res => {
          this.gridData = {
            data: res.dashBoardDataList || [],
            total: res.allMandatesCount || 0
          };
          // this.statuses = res.statusMap ? res.statusMap : [];
          this.loaderService.isLoading.next(false);
        }, err => {
          this.gridData = {
            data: [],
            total: 0
          };
          this.loaderService.isLoading.next(false);
        });
    } else {
      const mandateStatus = this.gridShow;
      this.dashBoard.getMandatesByFilter(this.state.filter, this.overviewPage, mandateStatus, this.state.sort).subscribe(
        result => {
          this.gridData = {
            data: result.dashBoardDataList || [],
            total: result.allMandatesCount || 0
          };
          this.loaderService.isLoading.next(false);
        }, err => {
          this.gridData = {
            data: [],
            total: 0
          };
          this.loaderService.isLoading.next(false);
        });
    }
  }

  changeViewState(section) {
    this.gridShow = section;
    this.overviewPage = { page: 1, pageSize: 10 };
    this.state = {
      skip: 0,
      take: 10,
      sort: [{
        field: 'entity_name',
        dir: 'asc'
      }],
      filter: {
        logic: 'and',
        filters: []
      }
    };

    if (section === 'all') {
      this.getAllMandatess();
    } else {
      const mandateStatus = section ? section : '';
      this.loaderService.isLoading.next(true);
      this.getMandatesCount();

      this.dashBoard.getMandatesByFilter(this.state.filter, this.overviewPage, mandateStatus, this.state.sort).subscribe(
        result => {
          this.gridData = {
            data: result.dashBoardDataList || [],
            total: result.allMandatesCount || 0
          };
          this.loaderService.isLoading.next(false);
        }, err => {
          this.gridData = {
            data: [],
            total: 0
          };
          this.loaderService.isLoading.next(false);
      });
    }
  }

  globalSearchFilter(searchFilter) {
    this.loaderService.isLoading.next(true);
    this.dashBoard.globalHeaderSearch(searchFilter).subscribe(
      result => {
        console.log(result);
        this.gridData = {
          data: result['body']['dashBoardDataList'] || [],
          total: result['body']['allMandatesCount'] || 0
        };
        this.tabset.tabs[0].active = true;
        this.gridShow = 'all';
        this.loaderService.isLoading.next(false);
      },
      err => {
        this.gridData = {
          data: [],
          total: 0
        };
        this.loaderService.isLoading.next(false);
      });
  }

  getMandatesCount() {
    this.dashBoard.getMadatesCount().subscribe(count => {
      if (count && count.mandatesCounts) {
        this.mandatesCounts.totalMandateCount = count.mandatesCounts.totalMandateCount || 0;
        this.mandatesCounts.createdMandateCount = count.mandatesCounts.createdMandateCount || 0;
        this.mandatesCounts.orginatedMandateCount = count.mandatesCounts.orginatedMandateCount || 0;
        this.mandatesCounts.allocatedtoanalyst = count.mandatesCounts.allocatedtoanalyst || 0;
        this.mandatesCounts.closedMandateCount = count.mandatesCounts.closedMandateCount || 0;
      }
    });
  }

  public getFrommServerData(): any {
    let selectedIds = [];

    if (this.mySelection.length > 0 ) {
      selectedIds = this.mySelection;
    }

    this.dashBoard.fetchExcelData(selectedIds).subscribe(records => {
      this.excel = [];
      if (records && records['dashBoardDataList'].length > 0) {
        records['dashBoardDataList'].forEach(row => {
          this.excel.push(row);
        });
        // this.excel.push(records['dashBoardDataList']);
        setTimeout( () => {
          this.excelService.exportAsExcelFile(this.excel, 'netops');
        }, 800);
      } else {
        this.toastr.warning('No records available to export', 'Excel export!');
        console.log('error');
      }
    });
  }

  getColumnDisplay() {
    this.dashBoard.getColumnFieldService().subscribe(res => {
      if (res && res['dashboardFieldMenu'].length > 0 ) {
        this.currentColumnSelection['sticky'] = res['dashboardFieldMenu'];
        this.currentColumnSelection['common'] = res['rightDashboardFieldMenu'];
        this.stickyColumnDimensions = res['dashboardFieldMenu'];
        this.commonColumnDimensions = res['rightDashboardFieldMenu'];
        // this.columnSegragate(res['dashboardFieldMenu']);
        this.columnDisplay();
        this.checkColumnCount();
      } else {
        this.currentColumnSelection = this.stickyColumnDimensions;
        this.columnDisplay();
        this.checkColumnCount();
      }
      this.currentColumnSelection['sticky'] = this.stickyColumnDimensions;
      this.currentColumnSelection['common'] = this.commonColumnDimensions;
      this.checkColumnCount();
    }, error => {
      this.currentColumnSelection['sticky'] = this.stickyColumnDimensions;
      this.currentColumnSelection['common'] = this.commonColumnDimensions;
      this.columnDisplay();
      this.checkColumnCount();
    });

  }

  cancelSingleMandate() {
    this.singleModuleSearch = {
      searchProductTypeText: '',
      searchInstituteText: '',
      searchBillingCompany: '',
      searchBillingCompanyContact: ''
    };
  }

  columnSegragate(rows) {
    this.stickyColumnDimensions = [];
    this.commonColumnDimensions = [];
    Object.assign(this.stickyColumnDimensions, rows);
    Object.assign(this.commonColumnDimensions, rows);

    rows.filter( (row, index) => {
      if (row.sticky) {
        this.stickyColumnDimensions[index] = [];
        this.commonColumnDimensions[index] = [];
        // name
       this.stickyColumnDimensions[index].field_name = row.field_name;
       this.commonColumnDimensions[index].field_name = row.field_name;
        // id
       this.stickyColumnDimensions[index].field_id = row.field_id;
       this.commonColumnDimensions[index].field_id = row.field_id;
        // boolean values
        this.stickyColumnDimensions[index].sticky = true;
        this.stickyColumnDimensions[index].checked = true;
        this.stickyColumnDimensions[index].status = true;
        this.stickyColumnDimensions[index].status = false;
        this.commonColumnDimensions[index].disabled = false;
        this.commonColumnDimensions[index].status = false;
        this.commonColumnDimensions[index].sticky = false;
        this.commonColumnDimensions[index].checked = false;
      } else {
        if (row.checked) {
          this.stickyColumnDimensions[index] = [];
          this.commonColumnDimensions[index] = [];
          // name
         this.stickyColumnDimensions[index].field_name = row.field_name;
         this.commonColumnDimensions[index].field_name = row.field_name;
          // id
         this.stickyColumnDimensions[index].field_id = row.field_id;
         this.commonColumnDimensions[index].field_id = row.field_id;
          // boolean values
          this.stickyColumnDimensions[index].sticky = false;
          this.stickyColumnDimensions[index].checked = false;
          this.stickyColumnDimensions[index].status = false;
          this.stickyColumnDimensions[index].status = false;
          this.commonColumnDimensions[index].disabled = false;
          this.commonColumnDimensions[index].status = true;
          this.commonColumnDimensions[index].sticky = false;
          this.commonColumnDimensions[index].checked = true;

        } else {
          this.stickyColumnDimensions[index] = [];
          this.commonColumnDimensions[index] = [];
          // name
         this.stickyColumnDimensions[index].field_name = row.field_name;
         this.commonColumnDimensions[index].field_name = row.field_name;
          // id
         this.stickyColumnDimensions[index].field_id = row.field_id;
         this.commonColumnDimensions[index].field_id = row.field_id;
          // boolean values
          this.stickyColumnDimensions[index].sticky = false;
          this.stickyColumnDimensions[index].checked = false;
          this.stickyColumnDimensions[index].status = false;
          this.stickyColumnDimensions[index].status = false;
          this.commonColumnDimensions[index].disabled = false;
          this.commonColumnDimensions[index].status = false;
          this.commonColumnDimensions[index].sticky = false;
          this.commonColumnDimensions[index].checked = false;
        }

      }
    });
  }

  columnDisplay() {
    this.stickyColumnDimensions.filter((col, index) => {
      if (col.sticky === true || col.sticky === 1) {
        // this.showCommonColumns.push(this.stickyColumnDimensions[index]);
        this.mainColumnDimenstions[col.field_id] = [];
        this.mainColumnDimenstions[col.field_id].checked = true;
        this.mainColumnDimenstions[col.field_id].sticky = true;
      } else {
        if (this.commonColumnDimensions[index].checked === true || this.commonColumnDimensions[index].checked === 1) {
          // this.showCommonColumns.push(this.stickyColumnDimensions[index]);
          this.mainColumnDimenstions[col.field_id] = [];
          this.mainColumnDimenstions[col.field_id].checked = true;
          this.mainColumnDimenstions[col.field_id].sticky = false;
        } else {
          this.mainColumnDimenstions[col.field_id] = [];
          this.mainColumnDimenstions[col.field_id].checked = false;
          this.mainColumnDimenstions[col.field_id].sticky = false;
        }
      }
    });
  }

  saveFieldSelection() {
    this.loaderService.isLoading.next(true);
    this.dashBoard.saveColumnFieldsSevice(this.stickyColumnDimensions, this.commonColumnDimensions).subscribe(res => {
      console.log(res);
      this.getColumnDisplay();
      this.loaderService.isLoading.next(false);
    }, err => {
      this.loaderService.isLoading.next(false);
    });
  }

  revertFieldSelection() {
    if (this.currentColumnSelection) {
      this.stickyColumnDimensions =  this.currentColumnSelection['sticky'];
      this.commonColumnDimensions = this.currentColumnSelection['common'];
      this.columnDisplay();
    }
  }

  newDate(date) {
    return this.datePip.transform(date, 'dd/MM/yyyy HH:mm');
  }

  onSearchProductTypeChange = (text$: Observable<string>) => {
    return text$.pipe(
      debounceTime(500),
      distinctUntilChanged(),
      switchMap(term =>
        this.searchGetProduct(term).pipe(
          catchError(() => {
            return of([]);
          })
        )
      )
    );
  }

  searchGetProduct(term: string) { // return
    return new Observable(sub => {
      if (term.length > 0) {
        this.dashBoard.onProductAutoComplete({'productName': term})
          .subscribe(products => {
            let product: any;
            this.searchProductName = [];
            product = products.body;
            const linesArr = [];
            if (product.length === 0) {
              linesArr.push(['No Record for this search']);
            }
            for (let i = 0; i < product.length; i++) {
              if (product[i]) {
                this.searchProductName.push(product[i]);
                linesArr.push(product[i]['PRODUCTNAME']);
              }
            }
            sub.next(linesArr);
          });
      } else {
        const linesArr = [];
        sub.next(linesArr);
      }
    });
  }

  searchInstitutionName = (text$: Observable<string>) => {
    return text$.pipe(
        debounceTime(500),
        distinctUntilChanged(),
        switchMap(term =>
          this.searchGetInstitutionName(term).pipe(
            catchError(() => {
              return of([]);
            }))
        )
    );
  }

  searchGetInstitutionName(term) {
    this.singleModuleSearch.searchInstituteText  = '';
    return new Observable(sub => {
      if (term.length > 0) {
        this.dashBoard.onInstitutionAutoComplete({'instituteName': term})
          .subscribe(institution => {
            let ins: any;
            ins = institution.body;
            const linesArr = [];
            this.searchInstituteName = [];
            if (!ins) {
              linesArr.push(['No Record for this search']);
            }
            for (let i = 0; i < ins.length; i++) {
              if (ins[i]) {
                this.searchInstituteName.push(ins[i]);
                linesArr.push(ins[i]['INSTITUTIONNAME'] );
              }
            }
            sub.next(linesArr);
          });
      } else {
        const linesArr = [];
        sub.next(linesArr);
      }
    });
  }

  selectedItem(item, searchedItem){
      if (searchedItem === 'searchProductName') {
        this.singleModuleSearch.searchProductTypeText = '';
        let localItem = [];
        if (item !== 'No Record for this search') {
          for (let i= 0; i < this.searchProductName.length; i++) {
            if (this.searchProductName[i].PRODUCTNAME === item.item) {
              localItem = this.searchProductName[i];
              this.productId = this.searchProductName[i]['PRODUCTID'];
            }
          }
          this.singleModuleSearch.searchProductTypeText = localItem['PRODUCTNAME'];
        }
      }
      if (searchedItem === 'searchInstituteName') {
        this.singleModuleSearch.searchInstituteText = '';
        let localItem = [];
        if (item !== 'No Record for this search') {
          for (let i= 0; i < this.searchInstituteName.length; i++) {
            if (this.searchInstituteName[i].INSTITUTIONNAME === item.item) {
              localItem = this.searchInstituteName[i];
              this.institutionId = this.searchInstituteName[i]['INSTITUTIONID'];
            }
          }
          this.singleModuleSearch.searchInstituteText = localItem['INSTITUTIONNAME'];
          this.isDisabledField();
        }
      }
      if (searchedItem === 'searchBillingComp') {
        this.singleModuleSearch.searchBillingCompany = '';
        let localItem = [];
        if (item !== 'No Record for this search') {
          for (let i= 0; i < this.searchBillingComp.length; i++) {
            if (this.searchBillingComp[i].company_name === item.item) {
              localItem = this.searchBillingComp[i];
            }
          }
          this.singleModuleSearch.searchBillingCompany = localItem['company_name'];

          this.dashBoard.getBAcompaniesList(this.singleModuleSearch.searchBillingCompany).subscribe(
            result => {
              const companies: any = result;
              this.companyContacts = companies.map(data => data['contact_full_name']);
            }
          );
        }
      }
      if (searchedItem === 'searchBillingCompContact') {
        this.singleModuleSearch.searchBillingCompanyContact = '';
        let localItem = [];
        if (item !== 'No Record for this search') {
          for (let i= 0; i < this.searchBillingCompContact.length; i++) {
            if (this.searchBillingCompContact[i].contact_full_name === item.item) {
              localItem = this.searchBillingCompContact[i];
            }
          }
          this.singleModuleSearch.searchBillingCompanyContact = localItem['contact_full_name'];
        }
      }
  }

  searchBillingCompany = (text$: Observable<string>) => {
    return text$.pipe(
        debounceTime(500),
        distinctUntilChanged(),
        switchMap(term =>
          this.searchGetBillingCompany(term).pipe(
            catchError(() => {
              return of([]);
            }))
        )
    );
  }

  searchGetBillingCompany(term) {
    this.companyContacts = [];
    this.singleModuleSearch.searchBillingCompany = '';
    this.singleModuleSearch.searchBillingCompanyContact = '';

    return new Observable(sub => {
          if (term.length > 0) {
            this.dashBoard.onBillingCompanyAutoComplete({'companyName': term})
              .subscribe(company => {
                let comp: any;
                this.searchBillingComp = [];
                comp = company.body;
                const linesArr = [];
                if (!comp) {
                  linesArr.push(['No Record for this search']); //
                }
                for (let i = 0; i < comp.length; i++) {
                  if (comp[i]) {
                    this.searchBillingComp.push(comp[i]);
                    linesArr.push(comp[i]['company_name'] );
                  }
                }
                if (this.singleModuleSearch.searchInstituteText === 'Individual' && comp.length === 0) {
                 // linesArr.push(term);
                 this.singleModuleSearch.searchBillingCompany = term;
                 this.isDisabledField();
                }
                sub.next(linesArr);
              });
          } else {
            const linesArr = [];
            sub.next(linesArr);
          }
    });
  }

  isDisabledField() {
    if ( this.singleModuleSearch.searchInstituteText === 'Individual') {
      return false;
    }
    if ( this.singleModuleSearch.searchBillingCompany ) {
      return false;
    }
    return true;
  }

  searchBillingCompanyContact = (text$: Observable<string>) => {
    return text$.pipe(
        debounceTime(500),
        distinctUntilChanged(),
        switchMap(term =>
          this.searchGetBillingCompanyContact(term).pipe(
            catchError(() => {
              return of([]);
            }))
        )
      );
  }

  searchGetBillingCompanyContact(term) {
    return new Observable(sub => {
          if (term.length > 0) {
            this.dashBoard.onBillingCompanyContactAutoComplete( {'companyName': this.singleModuleSearch.searchBillingCompany, 'contactName': term})
              .subscribe(company => {
                this.searchBillingCompContact = [];
                let ccontact: any;
                ccontact = company.body;
                const linesArr = [];
                if (!ccontact) {
                  linesArr.push(['No Record for this search']); // No Record for this search
                }
                for (let i = 0; i < ccontact.length; i++) {
                  if (ccontact[i]) {
                    this.searchBillingCompContact.push(ccontact[i])
                    linesArr.push(ccontact[i]['contact_full_name'] );
                  }
                }
                if ( this.singleModuleSearch.searchInstituteText === 'Individual' && ccontact.length === 0) {
                  this.singleModuleSearch.searchBillingCompanyContact = term;
                }
                sub.next(linesArr);
              });
          } else {
            const linesArr = [];
            sub.next(linesArr);
          }
    });
  }

  redirectToParentBonita() {
    this.dashBoard.getProcessIdToRedirectParent().subscribe( process => {
      console.log(process, '', process);
      if (process && process[0]) {
        window.location.href ='/bonita/portal/resource/process/SME%20Process/1.0/content/?id='+process[0].id+'&locale=en&mode=app&productName='+ this.singleModuleSearch.searchProductTypeText +'&instituteName='+ this.singleModuleSearch.searchInstituteText +'&bacontact='+ this.singleModuleSearch.searchBillingCompanyContact +'&bacompnay='+ this.singleModuleSearch.searchBillingCompany +'&source=NO&test=abcc';
      }
    });
  }

  public onSelectedKeysChange(e) {
    const len = this.mySelection.length;

    if (len === 0) {
        this.isChecked = false;
        this.selectAllState = 'unchecked';
    } else if (len > 0 && len < this.gridData.data.length) {
        this.isChecked = true;
        this.selectAllState = 'indeterminate';
    } else {
      this.isChecked = true;
        this.selectAllState = 'checked';
    }
  }

  public onSelectAllChange(checkedState: SelectAllCheckboxState) {
      if (checkedState === 'checked') {
          this.mySelection = this.gridData.data.map((item) => item.workflow_id);
          this.selectAllState = 'checked';
      } else {
          this.mySelection = [];
          this.selectAllState = 'unchecked';
      }
  }

  proceedToDelete() {
    this.modalRef.hide();
    this.dashBoard.deleteMandates(this.mySelection).subscribe(
      res => {
        console.log(res);
        this.removeSelection();
        this.getAllMandatess();
        this.toastr.success('Deleted successfully!', 'Delete Records!');
      }, err => {
        this.toastr.error('Something went wrong! Try again later', 'Delete Records!');
      });
  }

  removeSelection() {
    this.mySelection = [];
    this.isChecked = false;
    this.selectAllState = 'unchecked';
  }

  validateMandate() {
    console.log(this.datastring);
    this.bulkUploadService.validateMandates(this.datastring).subscribe(response => {
      console.log(response);
      this.bulkUploadSharedData.setMandateData(response), () => {};
      this.modalRef.hide();
      this.router.navigate(['/bulkmandate']);
    });
  }

  uploadFile(ev) {
    this.datastring = {};
    this.usrData = {
      'Product Name': this.singleModuleSearch.searchProductTypeText,
      'Institution Name': this.singleModuleSearch.searchInstituteText,
      'Billing Company': this.singleModuleSearch.searchBillingCompany,
      'Billing Company Contact': this.singleModuleSearch.searchBillingCompanyContact
    };

    let workBook = null;
    let jsonData = null;
    const reader = new FileReader();
    const file = ev.target.files[0];
    reader.onload = (event) => {
      const data = reader.result;
      workBook = XLSX.read(data, { type: 'binary' });
      jsonData = workBook.SheetNames.reduce((initial, name) => {
        const sheet = workBook.Sheets[name];
        initial['mandates'] = XLSX.utils.sheet_to_json(sheet);
        return initial;
      }, {});
      Object.assign(jsonData, this.usrData);
      this.datastring = JSON.stringify(jsonData);
    };
    reader.readAsBinaryString(file);
  }

  getComments() {
    this.dashBoard.getComments(this.workId).subscribe(responsedata => {
      this.filteredData = responsedata.dashBoardDataList;
      console.log(this.filteredData);
    });
  }

  addComment(value: string) {
    this.comment = value;
    this.userid = this.workId;
    this.userRole = '';
    this.dashBoard.addComment(this.comment, this.userRole, this.userid).subscribe(addedComment => {
      console.log(addedComment);
      this.comment = '';
      this.getComments();
    });
  }

  getMasterLink() {
    const url = window.location.href;

    let webCheck1 = url.indexOf('dev-bonita');
    let webCheck2 = url.indexOf('uat-bonita');

    if (webCheck1 > 0) {
      return 'http://52.66.123.3/#!/container/feeMaster';
    } else if (webCheck2 > 0) {
      return 'https://uat-notes.smefirst.com/sme-note/#!/container/feeMaster';
    } else {
      return 'http://52.66.123.3/#!/container/feeMaster';
    }
  }

  caseReject() {
    if (this.mySelection.length) {
      this.bsModalRef = this.modalService.show(CommentsModalComponent, { keyboard: false, ignoreBackdropClick: true });
      this.bsModalRef.content.action.subscribe((data) => {
        if (data) {
          const obj = {
            mandateIds: this.mySelection.toString(),
            comments: data
          };
          this.loaderService.isLoading.next(true);

          this.dashBoard.rejectMandates(obj).subscribe(
            result => {
              const successMandates = result['SuccessMandates'];
              const failedMandates = result['FailedMandates'];

              if (successMandates && successMandates.length) {
                this.toastr.success(successMandates.join(', '), 'Successfully Rejected:',
                    { timeOut: 8000 });
              }
              if (failedMandates && failedMandates.length) {
                this.toastr.warning(failedMandates.join(', '), 'Reject failed for:',
                    { timeOut: 8000 });
              }
              setTimeout(() => {
                this.removeSelection();
                this.getAllMandatess();
              }, 1000);
            },
            error => {
              this.loaderService.isLoading.next(false);
              this.removeSelection();
              this.toastr.error('Error occured', 'Error');
            });
        }
      });
    }
  }

  caseOnFloor() {
    if (this.mySelection.length) {
      const mandateIds = this.mySelection.toString();
      this.loaderService.isLoading.next(true);

      this.dashBoard.caseOnFloorMandates(mandateIds).subscribe(
        result => {
          const failedMandates = result['failedMandates'];

          if (failedMandates && failedMandates.length) {
            this.toastr.warning(failedMandates.join(', ') + '\nInfo Req is not approved', 'Case on floor failed for:',
                { timeOut: 6000 });
          } else {
            this.toastr.success('Successfully Submitted', 'Success');
          }
          setTimeout(() => {
            this.removeSelection();
            this.getAllMandatess();
          }, 1000);
        },
        error => {
          this.loaderService.isLoading.next(false);
          this.removeSelection();
          this.toastr.error('Error occured', 'Error');
        });
    }
  }

  generateOFS() {
    const mandateIds = this.mySelection.toString();
    this.dashBoard.generateOFSinvoice(mandateIds).subscribe(
      result => {
        console.log(result);
        this.excel = [];
        const records: any = result;
        if (records && records.length > 0) {
          records.forEach(row => {
            this.excel.push(row);
          });
          setTimeout(() => {
            console.log(this.excel);
            this.excelService.exportAsExcelFile(this.excel, 'OFS');
          }, 800);
        } else {
          this.toastr.warning('No records available to export', 'Excel export!');
          console.log('error');
        }
      },
      error => {
        this.removeSelection();
        this.toastr.error('Error occured', 'Error');
      });
  }

}
