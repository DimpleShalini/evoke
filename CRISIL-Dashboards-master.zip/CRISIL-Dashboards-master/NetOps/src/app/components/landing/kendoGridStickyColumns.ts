export const stickyColumnDimensions: any = [
    {
        column_type: 'left',
        field_name: 'Mandate ID',
        field_id: 'mandate_id',
        status: false,
        disabled: false,
        checked: false,
        sticky: false
    },
    {
        column_type: 'left',
        field_name: 'Mandate Created Date',
        field_id: 'mandate_created_date',
        status: false,
        disabled: false,
        checked: false,
        sticky: false
    },
    {
        column_type: 'left',
        field_name: 'Institution Name',
        field_id: 'institution_name',
        status: true,
        disabled: false,
        checked: true,
        sticky: true
    },
    {
        column_type: 'left',
        field_name: 'BD',
        field_id: 'bd_name',
        status: false,
        disabled: false,
        checked: false,
        sticky: false
    },
    {
        column_type: 'left',
        field_name: 'Entity Name',
        field_id: 'entity_name',
        status: true,
        disabled: false,
        checked: true,
        sticky: true
    },
    {
        column_type: 'left',
        field_name: 'Main case Status',
        field_id: 'case_current_status',
        status: false,
        disabled: false,
        checked: false,
        sticky: false
    },
    {
        column_type: 'left',
        field_name: 'Cordination Case Status',
        field_id: 'coordination_case_status',
        status: false,
        disabled: false,
        checked: false,
        sticky: false
    },
    {
        column_type: 'left',
        field_name: 'ISME Case Sub Status',
        field_id: 'workflow_status',
        status: false,
        disabled: false,
        checked: false,
        sticky: false
    },
    {
        column_type: 'left',
        field_name: 'Product',
        field_id: 'product',
        status: false,
        disabled: false,
        checked: false,
        sticky: false
    },
    {
        column_type: 'left',
        field_name: 'Mandate Originated Date',
        field_id: 'mandate_originated_date',
        status: false,
        disabled: false,
        checked: false,
        sticky: false
    },
    {
        column_type: 'left',
        field_name: 'TL',
        field_id: 'tl',
        status: false,
        disabled: false,
        checked: false,
        sticky: false
    },
    {
        column_type: 'left',
        field_name: 'Analyst',
        field_id: 'analyst',
        status: false,
        disabled: false,
        checked: false,
        sticky: false
    },
    {
        column_type: 'left',
        field_name: 'TAT',
        field_id: 'tat',
        status: false,
        disabled: false,
        checked: false,
        sticky: false
    },
    {
        column_type: 'left',
        field_name: 'Last Updated Date',
        field_id: 'last_updated_date',
        status: false,
        disabled: false,
        checked: false,
        sticky: false
    },
    {
        column_type: 'left',
        field_name: 'Credit Exposure by Bank',
        field_id: 'credit_exposure_by_bank',
        status: false,
        disabled: false,
        checked: false,
        sticky: false
    },
    {
        column_type: 'left',
        field_name: 'Order ID',
        field_id: 'order_id',
        status: false,
        disabled: false,
        checked: false,
        sticky: false
    },
    {
        column_type: 'left',
        field_name: 'SME First Status',
        field_id: 'sme_first_status',
        status: false,
        disabled: false,
        checked: false,
        sticky: false
    },
    {
        column_type: 'left',
        field_name: 'Lender',
        field_id: 'lender',
        status: false,
        disabled: false,
        checked: false,
        sticky: false
    }
];

export const commonColumnDimensions: any = [
    {
        column_type: 'right',
        field_name: 'Mandate ID',
        field_id: 'mandate_id',
        status: true,
        disabled: false,
        checked: true,
        sticky: false
    },
    {
        column_type: 'right',
        field_name: 'Mandate Created Date',
        field_id: 'mandate_created_date',
        status: true,
        disabled: false,
        checked: true,
        sticky: false
    },
    {
        column_type: 'right',
        field_name: 'Institution Name',
        field_id: 'institution_name',
        status: false,
        disabled: true,
        checked: false,
        sticky: false
    },
    {
        column_type: 'right',
        field_name: 'BD',
        field_id: 'bd_name',
        status: true,
        disabled: false,
        checked: true,
        sticky: false
    },
    {
        column_type: 'right',
        field_name: 'Entity Name',
        field_id: 'entity_name',
        status: false,
        disabled: true,
        checked: false,
        sticky: false
    },
    {
        column_type: 'right',
        field_name: 'Main Case Status',
        field_id: 'case_current_status',
        status: true,
        disabled: false,
        checked: true,
        sticky: false
    },
    {
        column_type: 'right',
        field_name: 'Cordination Case Status',
        field_id: 'coordination_case_status',
        status: true,
        disabled: false,
        checked: true,
        sticky: false
    },
    {
        column_type: 'right',
        field_name: 'ISME Case Sub Status',
        field_id: 'workflow_status',
        status: true,
        disabled: false,
        checked: true,
        sticky: false
    },
    {
        column_type: 'right',
        field_name: 'Product',
        field_id: 'product',
        status: false,
        disabled: false,
        checked: true,
        sticky: false
    },
    {
        column_type: 'right',
        field_name: 'Mandate Originated Date',
        field_id: 'mandate_originated_date',
        status: false,
        disabled: false,
        checked: true,
        sticky: false
    },
    {
        column_type: 'right',
        field_name: 'TL',
        field_id: 'tl',
        status: false,
        disabled: false,
        checked: true,
        sticky: false
    },
    {
        column_type: 'right',
        field_name: 'Analyst',
        field_id: 'analyst',
        status: false,
        disabled: false,
        checked: true,
        sticky: false
    },
    {
        column_type: 'right',
        field_name: 'TAT',
        field_id: 'tat',
        status: false,
        disabled: false,
        checked: true,
        sticky: false
    },
    {
        column_type: 'right',
        field_name: 'Last Updated Date',
        field_id: 'last_updated_date',
        status: false,
        disabled: false,
        checked: true,
        sticky: false
    },
    {
        column_type: 'right',
        field_name: 'Credit Exposure by Bank',
        field_id: 'credit_exposure_by_bank',
        status: false,
        disabled: false,
        checked: true,
        sticky: false
    },
    {
        column_type: 'right',
        field_name: 'Order ID',
        field_id: 'order_id',
        status: false,
        disabled: false,
        checked: false,
        sticky: false
    },
    {
        column_type: 'right',
        field_name: 'SME First Status',
        field_id: 'sme_first_status',
        status: false,
        disabled: false,
        checked: false,
        sticky: false
    },
    {
        column_type: 'right',
        field_name: 'Lender',
        field_id: 'lender',
        status: false,
        disabled: false,
        checked: false,
        sticky: false
    }
];
