import { Injectable } from '@angular/core';
// import { Observable, of, throwError } from 'rxjs';
import {
  HttpClient,
  HttpResponse,
  HttpHeaders,
  HttpHandler,
  HttpErrorResponse
} from '@angular/common/http';
import { SettingsService } from './settings.service';
import { Observable, forkJoin } from 'rxjs';
import { map } from 'rxjs/operators';


@Injectable()
export class DashboardService {
  private API_ALL_MANDATES_URL = '/extension/smekpi';
  private API_GET_COLUMN_FIELDS = '/extension/smekpi';
  private API_SET_COLUMN_FIELDS = '/extension/smedashboard';
  private API_GET_AUTO_PRODUCT = '/extension/getMasterData';
  private API_GET_COLUMN_DATA = '/extension/smedashboard?f=getnetopsmandates';
  private API_GET_MANDATES_URL_FILTERS = '/extension/smedashboard?f=getnetopsmandatesbystatus';
  private API_GET_EXCEL_MANDATES = '/extension/smedashboard?f=getnetopsmandatesforexcel';
  private API_POST_COMMENTS = '/extension/smedashboard?f=savecomments';
  private API_GET_COMMENTS = '/extension/smekpi';

  constructor(
    private http: HttpClient,
    private settingsService: SettingsService
  ) { }

  checkUserRoles(user) {
    return this.http.post(`/bonita/API/extension/mandateUtility?f=getUserRoles`, { userName: user });
  }

  getAllMandatesDummy() {
    return this.http.get<any>(this.settingsService.getBonitaApiBaseUrl() + this.API_GET_COLUMN_FIELDS + '?c=0&p=10&f=getAllMandates');
  }

  getAllMandatesWithFilters(filter?, page?, sort?) {
    //    POST /api/v1/purchaseorder
    return this.http.post<any>(this.settingsService.getBonitaApiBaseUrl() + this.API_GET_COLUMN_DATA, {
      filter: filter,
      page: page,
      sort: sort
    });
  }

  deleteMandates(rec) {
    const response1 = this.http.get<any>(this.settingsService.getBonitaApiBaseUrl() + this.API_ALL_MANDATES_URL + '?c=0&p=10&f=deletemandates&ids=' + rec.join());
    const response2 = this.http.post<any>('/bonitaAPI/accesssme/deleteMandateFromSME', { mandateIds: rec.join() });
    return forkJoin([response1, response2]);
  }

  getProducts() {
    return this.http.post('/bonita/API/extension/getMasterData?f=products', {});
  }

  onProductAutoComplete(obj) {
    // return this.http.get<any>('https://reqres.in/api/users');
    return this.http.post<any>(
      this.settingsService.getBonitaApiBaseUrl() +
      this.API_GET_AUTO_PRODUCT + '?f=product',
      obj,
      { observe: 'response' }
    );
  }

  onInstitutionAutoComplete(obj) {
    return this.http.post<any>(
      this.settingsService.getBonitaApiBaseUrl() +
      this.API_GET_AUTO_PRODUCT + '?f=institution',
      obj,
      { observe: 'response' }
    );
  }

  onBillingCompanyAutoComplete(obj) {
    return this.http.post<any>(
      this.settingsService.getBonitaApiBaseUrl() +
      this.API_GET_AUTO_PRODUCT + '?f=bacompany',
      obj,
      { observe: 'response' }
    );
  }

  onBillingCompanyContactAutoComplete(obj) {
    return this.http.post<any>(
      this.settingsService.getBonitaApiBaseUrl() +
      this.API_GET_AUTO_PRODUCT + '?f=bacompanycontact',
      obj,
      { observe: 'response' }
    );
  }

  getBAcompaniesList(companyName) {
    return this.http.post('/bonita/API/extension/getMasterData?f=bacompaniescontact', { companyName });
  }

  getColumnFieldService() {
    return this.http.get(
      this.settingsService.getBonitaApiBaseUrl() +
      this.API_GET_COLUMN_FIELDS +
      '?c=0&p=10&f=getdashboardfields'
    );
  }

  saveColumnFieldsSevice(leftColumn, rightColumn) {
    return this.http.post<any>(
      this.settingsService.getBonitaApiBaseUrl() +
      this.API_SET_COLUMN_FIELDS +
      '?c=0&p=10&f=saveconfiguration',
      { 'dashboardFieldMenu': leftColumn, 'rightDashboardFieldMenu': rightColumn },
      { observe: 'response' }
    );
  }

  getMadatesCount() {
    return this.http.get<any>(this.settingsService.getBonitaApiBaseUrl() + this.API_ALL_MANDATES_URL + '?c=0&p=0&f=getOverAllCountsForNetOps');
  }

  getMandatesByFilter(filter?, page?, mandateStatus?, sort?) {
    return this.http.post<any>(this.settingsService.getBonitaApiBaseUrl() + this.API_GET_MANDATES_URL_FILTERS,
      { filter, page, mandateStatus, sort });
  }

  getProcessIdToRedirectParent() {
    return this.http.get('/bonita/API/bpm/process?f=name=SME Process&p=0&c=1&o=version%20desc&f=activationState=ENABLED');
  }

  saveSingleNOMandate(productName, institutionName, billingCompany, billingCompanyContact, userid) {
    return this.http.post<any>('/bonitaAPI/accesssme/createMandate?source=NO', {
      "userId": userid,
      "productName": productName,
      "institutionName": institutionName,
      "billingCompany": billingCompany,
      "billingCompanyContact": billingCompanyContact,
      "entityName": '',
      "orderId": '',
      "lender": '',
      "smeFirstStatus": ''
    });
  }

  fetchExcelData(data) {
    if (data.length > 0) {
      return this.http.post(this.settingsService.getBonitaApiBaseUrl() + this.API_GET_EXCEL_MANDATES, { 'requestIds': data.join() });
    } else {
      return this.http.post(this.settingsService.getBonitaApiBaseUrl() + this.API_GET_EXCEL_MANDATES, {});
    }
  }

  //  getColumnsAndData() {
  //     return Observable.forkJoin(
  //     this.http.get(this.settingsService.getBonitaApiBaseUrl() + this. + '?c=0&p=10&f=getdashboardfields'),
  //     this.http.get(this.settingsService.getBonitaApiBaseUrl() + this. + '?c=0&p=10&f=getAllMandates')
  //     );
  //  }
  //  getColumnsAndData() {
  //    const c1 = this.http.get(this.settingsService.getBonitaApiBaseUrl() + this. + '?c=0&p=10&f=getdashboardfields');
  //    const c2 = this.http.get(this.settingsService.getBonitaApiBaseUrl() + this. + '?c=0&p=10&f=getAllMandates');
  //    return Observable.forkJoin([c1, c2]);
  //   }
  globalHeaderSearch(globalSearch) {
    return this.http.post<any>(
      this.settingsService.getBonitaApiBaseUrl() +
      this.API_SET_COLUMN_FIELDS +
      '?f=getnetopsmandatesforglobalsearch',
      {
        'filter': {
          'filters': [
            {
              'filters': [
                {
                  'field': '',
                  'operator': '',
                  'value': ''
                }

              ]

            },

          ],
          'logic': 'and'
        },
        'page': {
          'page': 1,
          'pageSize': 10
        },
        'sort': {
          'dir': '',
          'field': ''
        },
        'columnName': globalSearch.searchFilter ? globalSearch.searchFilter : 'all',
        'searchString': globalSearch.searchWord
      },
      { observe: 'response' }
    );
  }
  getComments(workflow_id) {
    return this.http.get<any>(this.settingsService.getBonitaApiBaseUrl() + this.API_GET_COMMENTS + '?f=getcomments&c=' + workflow_id + '&p=""');
  }

  addComment(Comment, Role, id) {
    return this.http.post(this.settingsService.getBonitaApiBaseUrl() + this.API_POST_COMMENTS, {
      comment: Comment,
      userRole: Role,
      workflow_id: id
    });
  }

  rejectMandates(payload) {
    return this.http.post(this.settingsService.getBonitaApiBaseUrl() + '/extension/mandateUtility?f=bulkReject', payload );
  }

  caseOnFloorMandates(mandatesList) {
    return this.http.post(this.settingsService.getBonitaApiBaseUrl() + '/extension/mandateUtility?f=caseonfloor', { mandateIds: mandatesList });
  }

  generateOFSinvoice(mandateIds) {
    return this.http.post('/bonitaAPI/accesssme/generateOFSReport?mandateIds=' + mandateIds, {});
  }

}
