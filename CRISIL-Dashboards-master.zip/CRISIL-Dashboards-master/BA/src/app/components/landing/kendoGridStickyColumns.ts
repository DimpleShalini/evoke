export const stickyColumnDimensions: any = [
    {
        column_type: 'left',
        field_name: 'Allocation Date',
        field_id: 'allocation_date',
        status: false,
        disabled: false,
        checked: false,
        sticky: false
    },
    {
        column_type: 'left',
        field_name: 'Mandate ID',
        field_id: 'mandate_id',
        status: false,
        disabled: false,
        checked: false,
        sticky: false
    },
    {
        column_type: 'left',
        field_name: 'Institution Name',
        field_id: 'institution_name',
        status: true,
        disabled: false,
        checked: true,
        sticky: true
    },
    {
        column_type: 'left',
        field_name: 'Entity Name',
        field_id: 'entity_name',
        status: true,
        disabled: false,
        checked: true,
        sticky: true
    },
    {
        column_type: 'left',
        field_name: 'Entity Contact Person Name',
        field_id: 'entity_contact_person_name',
        status: false,
        disabled: false,
        checked: false,
        sticky: false
    },
    {
        column_type: 'left',
        field_name: 'Entity Contact Number',
        field_id: 'entity_contact_number',
        status: false,
        disabled: false,
        checked: false,
        sticky: false
    },
    {
        column_type: 'left',
        field_name: 'Entity Contact Person Email ID',
        field_id: 'entity_contact_person_email_id',
        status: false,
        disabled: false,
        checked: false,
        sticky: false
    },
    {
        column_type: 'left',
        field_name: 'Service Type/Activity',
        field_id: 'service_type',
        status: false,
        disabled: false,
        checked: false,
        sticky: false
    },
    {
        column_type: 'left',
        field_name: 'QC Checks by Network Operations',
        field_id: 'qc_checks_by_network_operations',
        status: false,
        disabled: false,
        checked: false,
        sticky: false
    },
    {
        column_type: 'left',
        field_name: 'BA Status',
        field_id: 'ba_status',
        status: false,
        disabled: false,
        checked: false,
        sticky: false
    },
    {
        column_type: 'left',
        field_name: 'Completion Date',
        field_id: 'complition_date',
        status: false,
        disabled: false,
        checked: false,
        sticky: false
    },
    {
        column_type: 'left',
        field_name: 'Date Of Site Visit',
        field_id: 'date_of_site_visit',
        status: false,
        disabled: false,
        checked: false,
        sticky: false
    },
    {
        column_type: 'left',
        field_name: 'Main Case Status',
        field_id: 'case_current_status',
        status: false,
        disabled: false,
        checked: false,
        sticky: false
    }
];

export const commonColumnDimensions: any = [
    {
        column_type: 'right',
        field_name: 'Allocation Date',
        field_id: 'allocation_date',
        status: false,
        disabled: false,
        checked: true,
        sticky: false
    },
    {
        column_type: 'right',
        field_name: 'Mandate ID',
        field_id: 'mandate_id',
        status: false,
        disabled: false,
        checked: true,
        sticky: false
    },
    {
        column_type: 'right',
        field_name: 'Institution Name',
        field_id: 'institution_name',
        status: false,
        disabled: true,
        checked: false,
        sticky: false
    },
    {
        column_type: 'right',
        field_name: 'Entity Name',
        field_id: 'entity_name',
        status: false,
        disabled: true,
        checked: false,
        sticky: false
    },
    {
        column_type: 'right',
        field_name: 'Entity Contact Person Name',
        field_id: 'entity_contact_person_name',
        status: false,
        disabled: false,
        checked: true,
        sticky: false
    },
    {
        column_type: 'right',
        field_name: 'Entity Contact Number',
        field_id: 'entity_contact_number',
        status: false,
        disabled: false,
        checked: true,
        sticky: false
    },
    {
        column_type: 'right',
        field_name: 'Entity Contact Person Email ID',
        field_id: 'entity_contact_person_email_id',
        status: false,
        disabled: false,
        checked: true,
        sticky: false
    },
    {
        column_type: 'right',
        field_name: 'Service Type/Activity',
        field_id: 'service_type',
        status: false,
        disabled: false,
        checked: true,
        sticky: false
    },
    {
        column_type: 'right',
        field_name: 'QC Checks by Network Operations',
        field_id: 'qc_checks_by_network_operations',
        status: false,
        disabled: false,
        checked: true,
        sticky: false
    },
    {
        column_type: 'right',
        field_name: 'BA Status',
        field_id: 'ba_status',
        status: false,
        disabled: false,
        checked: true,
        sticky: false
    },
    {
        column_type: 'right',
        field_name: 'Completion Date',
        field_id: 'complition_date',
        status: false,
        disabled: false,
        checked: true,
        sticky: false
    },
    {
        column_type: 'right',
        field_name: 'Date Of Site Visit',
        field_id: 'date_of_site_visit',
        status: false,
        disabled: false,
        checked: true,
        sticky: false
    },
    {
        column_type: 'right',
        field_name: 'Main Case Status',
        field_id: 'case_current_status',
        status: false,
        disabled: false,
        checked: true,
        sticky: false
    }
];
