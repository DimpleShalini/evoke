import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { DatePipe } from '@angular/common';

import { GridDataResult, SelectAllCheckboxState, PageChangeEvent } from '@progress/kendo-angular-grid';
import { SortDescriptor, State, CompositeFilterDescriptor } from '@progress/kendo-data-query';
import { DialogAction } from '@progress/kendo-angular-dialog';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { TabsetComponent } from 'ngx-bootstrap/tabs';
import { CookieService } from 'ngx-cookie-service';
import { ToastrService } from 'ngx-toastr';

import { DashboardService } from '../../services/dashboard.service';
import { LoaderService } from '../../loader.service';
import { ExcelServicesService } from '../../services/excel.service';
import { BulkuploadService } from '../../services/bulkupload.service';
import { BulkuploadSharedData } from '../../services/bulkUpload.sharedData.service';
import { DataService } from '../../services/share.service';
import { stickyColumnDimensions, commonColumnDimensions  } from './kendoGridStickyColumns';

@Component({
  selector: 'landing-component',
  templateUrl: './landing.component.html',
  styleUrls: ['./landing.component.scss'],
  providers: [DatePipe]
})
export class LandingComponent implements OnInit {
  @ViewChild('tabset', { static: true }) tabset: TabsetComponent;

  public filter: CompositeFilterDescriptor;
  public state: State = {
    skip: 0,
    take: 10,
    sort: [{
      field: 'entity_name',
      dir: 'asc'
    }],
    filter: {
      logic: 'and',
      filters: []
    }
  };
  overviewPage = { page: 1, pageSize: 10 };
  public gridData: GridDataResult;
  public comment: string = '';
  public role: string;
  public userid: number;
  public opened = false;
  public actionsLayout: string = 'normal';
  public workId: any;
  public myActions = [{ text: 'Cancel' },
                      { text: 'Add Comment', primary: true }
                     ]
  gridShow: string = 'all';
  modalRef: BsModalRef;
  showCommonColumns: any = [];
  stickyCount: number;
  usrData: any;

  statuses = [
    { name: 'Allocated to Reviewer Team 1'},
    { name: 'Allocated to Team 1 Analyst' },
    { name: 'BD originated' },
    { name: 'Info req approved'},
    { name: 'Info req received'},
    { name: 'Mandate Created' },
    { name: 'Team 1 rejected' },
    { name: 'Team 2 Reviewer approved' }
  ];

  mandatesCounts = {
    totalMandateCount: 0,
    inProcessMandateCount: 0,
    approvedMandateCount: 0,
    rejectedMandateCount: 0,
    droppedMandateCount: 0
  };

  mainColumnDimenstions = {
    allocation_date             : { sticky: false, checked: true },
    mandate_id                  : { sticky: false, checked: true },
    entity_contact_person_name  : { sticky: false, checked: true },
    institution_name            : { sticky: true, checked: true },
    entity_contact_number       : { sticky: false, checked: true },
    entity_name                 : { sticky: true, checked: true },
    entity_contact_person_email_id: { sticky: false, checked: true },
    service_type                : { sticky: false, checked: true },
    qc_checks_by_network_operations: { sticky: false, checked: true },
    ba_status                   : { sticky: false, checked: true },
    complition_date             : { sticky: false, checked: true },
    date_of_site_visit          : { sticky: false, checked: true },
    case_current_status         : { sticky: false, checked: true }
  };
  datastring: any;

  stickyColumnDimensions: any = stickyColumnDimensions;
  commonColumnDimensions: any = commonColumnDimensions;

  public mySelection: number[] = [];
  public selectAllState: SelectAllCheckboxState = 'unchecked';
  excel = [];
  isChecked: boolean = false;
  currentColumnSelection: any = [];
  filteredData: any;
  userrole: string;

  constructor(
    private loaderService: LoaderService,
    private dashBoard: DashboardService,
    private datePip: DatePipe,
    private modalService: BsModalService,
    private excelService: ExcelServicesService,
    private bulkUploadService: BulkuploadService,
    private bulkUploadSharedData: BulkuploadSharedData,
    private router: Router,
    private toastr: ToastrService,
    private data: DataService,
    public cookieService: CookieService) {

  }

  ngOnInit() {
    this.getColumnDisplay();
    this.getAllMandatess();

    this.data.search.subscribe(searchFilter => {
      if (searchFilter.searchWord === '') {
        this.getAllMandatess();
      }
      if (searchFilter.searchWord) {
        this.globalSearchFilter(searchFilter);
      }
    });
  }

  updateCheckedOptions(options, event, type?, ind?) {
    if (type && type === 'sticky') {
      this.stickyColumnDimensions[ind].sticky = !this.stickyColumnDimensions[ind].sticky;
      this.stickyColumnDimensions[ind].checked = !this.stickyColumnDimensions[ind].checked;
      this.stickyColumnDimensions[ind].status = !this.stickyColumnDimensions[ind].status;
      if (this.stickyColumnDimensions[ind].checked) {
        if (this.commonColumnDimensions[ind].checked) {
          this.commonColumnDimensions[ind].checked = !this.commonColumnDimensions[ind].checked;
        }
        this.commonColumnDimensions[ind].disabled = true;
      } else {
        this.commonColumnDimensions[ind].disabled = false;
        this.commonColumnDimensions[ind].checked = false;
      }
      this.isSticky(this.stickyColumnDimensions[ind].sticky);
      this.checkColumnCount();
    } else {
      this.commonColumnDimensions[ind].checked = !this.commonColumnDimensions[ ind ].checked;
      this.commonColumnDimensions[ind].status = !this.commonColumnDimensions[ ind ].status;
      this.isSticky(this.stickyColumnDimensions[ind].sticky);
    }
  }

  checkColumnCount() {
    this.stickyCount = 0;
    this.stickyColumnDimensions.forEach(item => {
      if (item.checked) {
        this.stickyCount = this.stickyCount + 1;
      }
    });
    if (this.stickyCount >= 2) {
      this.stickyColumnDimensions.forEach(item => {
        if (!item.checked) {
          item.disabled = true;
        }
      });
    } else {
      this.stickyColumnDimensions.forEach(item => {
        if (!item.checked) {
          item.disabled = false;
        }
      });
    }
  }

  isSticky(col) {
    return true;
  }

  openModal(options, dataItem, type?) {
    if (type === 'delete') {
      if (this.mySelection && this.mySelection.length < 1) return;
    }

    this.modalRef = this.modalService.show(options, { keyboard: false, ignoreBackdropClick: true });
    if (type === 'configureColumns') {
      this.checkColumnCount();
    }
    if (type === 'cmnt') {
      this.workId = dataItem.workflow_id;
      this.getComments();
    }
    if (type === 'link') {
      // this.copyInputMessage(userinput);
    }
  }

  public filterChange(filter: CompositeFilterDescriptor): void {
    this.overviewPage.page = 1;
    this.overviewPage.pageSize = 10;
    this.state.skip = 0;
    this.state.take = 10;
    this.state.filter = filter;
    this.getAllMandatess();
  }

  public sortChange(sort: SortDescriptor[]): void {
    this.state.sort = sort;
    this.getAllMandatess();
  }

  public pageChange({ skip, take }: PageChangeEvent): void {
    this.state.skip = skip;
    this.state.take = take;
    this.overviewPage.page = skip / 10 + 1;
    this.overviewPage.pageSize = take;
    this.getAllMandatess();
  }

  getAllMandatess() {
    this.loaderService.isLoading.next(true);
    this.getMandatesCount();

    if (this.gridShow === 'all') {
      this.dashBoard.getAllMandatesWithFilters(this.state.filter, this.overviewPage, this.state.sort)
        .subscribe(res => {
          this.gridData = {
            data: res.dashBoardDataList || [],
            total: res.allMandatesCount || 0
          };
          // this.statuses = res.statusMap ? res.statusMap : [];
          this.loaderService.isLoading.next(false);
        }, err => {
          this.gridData = {
            data: [],
            total: 0
          };
          this.loaderService.isLoading.next(false);
        });
    } else {
      const mandateStatus = this.gridShow;
      this.dashBoard.getMandatesByFilter(this.state.filter, this.overviewPage, mandateStatus, this.state.sort).subscribe(
        result => {
          this.gridData = {
            data: result.dashBoardDataList || [],
            total: result.allMandatesCount || 0
          };
          this.loaderService.isLoading.next(false);
        }, err => {
          this.gridData = {
            data: [],
            total: 0
          };
          this.loaderService.isLoading.next(false);
        });
    }
  }

  changeViewState(section) {
    this.gridShow = section;
    this.overviewPage = { page: 1, pageSize: 10 };
    this.state = {
      skip: 0,
      take: 10,
      sort: [{
        field: 'entity_name',
        dir: 'asc'
      }],
      filter: {
        logic: 'and',
        filters: []
      }
    };

    if (section === 'all') {
      this.getAllMandatess();
    } else {
      const mandateStatus = section ? section : '';
      this.loaderService.isLoading.next(true);
      this.getMandatesCount();

      this.dashBoard.getMandatesByFilter(this.state.filter, this.overviewPage, mandateStatus, this.state.sort).subscribe(
        result => {
          this.gridData = {
            data: result.dashBoardDataList || [],
            total: result.allMandatesCount || 0
          };
          this.loaderService.isLoading.next(false);
        }, err => {
          this.gridData = {
            data: [],
            total: 0
          };
          this.loaderService.isLoading.next(false);
      });
    }
  }

  globalSearchFilter(searchFilter) {
    this.tabset.tabs[0].active = true;
    this.gridShow = 'all';
    this.loaderService.isLoading.next(true);

    this.dashBoard.globalHeaderSearch(searchFilter).subscribe(result => {
      console.log(result);
      this.gridData = {
        data: result['dashBoardDataList'] || [],
        total: result['allMandatesCount'] || 0
      };
      this.loaderService.isLoading.next(false);
    }, err => {
      this.loaderService.isLoading.next(false);
    });
  }

  getMandatesCount() {
    this.dashBoard.getMadatesCount().subscribe(count => {
      if (count && count.mandatesCounts) {
        this.mandatesCounts.totalMandateCount = count.mandatesCounts.totalMandateCount ? count.mandatesCounts.totalMandateCount : 0;
        this.mandatesCounts.inProcessMandateCount = count.mandatesCounts.inProcessMandateCount ? count.mandatesCounts.inProcessMandateCount : 0;
        this.mandatesCounts.approvedMandateCount = count.mandatesCounts.approvedMandateCount ? count.mandatesCounts.approvedMandateCount : 0;
        this.mandatesCounts.rejectedMandateCount = count.mandatesCounts.rejectedMandateCount ? count.mandatesCounts.rejectedMandateCount : 0;
        this.mandatesCounts.droppedMandateCount = count.mandatesCounts.droppedMandateCount ? count.mandatesCounts.droppedMandateCount : 0;
      }
    });
  }

  public getFrommServerData(): any {
    let selectedIds = [];

    if (this.mySelection.length > 0) {
      selectedIds = this.mySelection;
    }

    this.dashBoard.fetchExcelData(selectedIds).subscribe(records => {
      this.excel = [];
      if (records && records['dashBoardDataList'].length > 0) {
        records['dashBoardDataList'].forEach(row => {
          this.excel.push(row);
        });
        // this.excel.push(records['dashBoardDataList']);
        setTimeout(() => {
          this.excelService.exportAsExcelFile(this.excel, 'ba');
        }, 800);
      } else {
        this.toastr.warning('No records available to export', 'Excel export!');
        console.log('error');
      }
    });
  }

  getColumnDisplay() {
    this.dashBoard.getColumnFieldService().subscribe(res => {
      if (res && res['dashboardFieldMenu'].length > 0) {
        this.currentColumnSelection['sticky'] = res['dashboardFieldMenu'];
        this.currentColumnSelection['common'] = res['rightDashboardFieldMenu'];
        this.stickyColumnDimensions = res['dashboardFieldMenu'];
        this.commonColumnDimensions = res['rightDashboardFieldMenu'];
        this.columnDisplay();
      } else {
        this.currentColumnSelection = this.stickyColumnDimensions;
        this.columnDisplay();
      }
      this.currentColumnSelection['sticky'] = this.stickyColumnDimensions;
      this.currentColumnSelection['common'] = this.commonColumnDimensions;
      this.checkColumnCount();
    }, error => {
      this.currentColumnSelection['sticky'] = this.stickyColumnDimensions;
      this.currentColumnSelection['common'] = this.commonColumnDimensions;
      this.columnDisplay();
    });

  }

  columnSegragate(rows) {

    this.stickyColumnDimensions = [];
    this.commonColumnDimensions = [];
    Object.assign(this.stickyColumnDimensions, rows);
    Object.assign(this.commonColumnDimensions, rows);
    rows.filter((row, index) => {
      if (row.sticky) {
        this.stickyColumnDimensions[index] = [];
        this.commonColumnDimensions[index] = [];
        // name
        this.stickyColumnDimensions[index].field_name = row.field_name;
        this.commonColumnDimensions[index].field_name = row.field_name;
        // id
        this.stickyColumnDimensions[index].field_id = row.field_id;
        this.commonColumnDimensions[index].field_id = row.field_id;
        // boolean values
        this.stickyColumnDimensions[index].sticky = true;
        this.stickyColumnDimensions[index].checked = true;
        this.stickyColumnDimensions[index].status = true;
        this.stickyColumnDimensions[index].status = false;
        this.commonColumnDimensions[index].disabled = false;
        this.commonColumnDimensions[index].status = false;
        this.commonColumnDimensions[index].sticky = false;
        this.commonColumnDimensions[index].checked = false;
      } else {
        if (row.checked) {
          this.stickyColumnDimensions[index] = [];
          this.commonColumnDimensions[index] = [];
          // name
          this.stickyColumnDimensions[index].field_name = row.field_name;
          this.commonColumnDimensions[index].field_name = row.field_name;
          // id
          this.stickyColumnDimensions[index].field_id = row.field_id;
          this.commonColumnDimensions[index].field_id = row.field_id;
          // boolean values
          this.stickyColumnDimensions[index].sticky = false;
          this.stickyColumnDimensions[index].checked = false;
          this.stickyColumnDimensions[index].status = false;
          this.stickyColumnDimensions[index].status = false;
          this.commonColumnDimensions[index].disabled = false;
          this.commonColumnDimensions[index].status = true;
          this.commonColumnDimensions[index].sticky = false;
          this.commonColumnDimensions[index].checked = true;

        } else {
          this.stickyColumnDimensions[index] = [];
          this.commonColumnDimensions[index] = [];
          // name
          this.stickyColumnDimensions[index].field_name = row.field_name;
          this.commonColumnDimensions[index].field_name = row.field_name;
          // id
          this.stickyColumnDimensions[index].field_id = row.field_id;
          this.commonColumnDimensions[index].field_id = row.field_id;
          // boolean values
          this.stickyColumnDimensions[index].sticky = false;
          this.stickyColumnDimensions[index].checked = false;
          this.stickyColumnDimensions[index].status = false;
          this.stickyColumnDimensions[index].status = false;
          this.commonColumnDimensions[index].disabled = false;
          this.commonColumnDimensions[index].status = false;
          this.commonColumnDimensions[index].sticky = false;
          this.commonColumnDimensions[index].checked = false;
        }

      }
    });
  }

  columnDisplay() {

    this.stickyColumnDimensions.filter((col, index) => {
      if (col.sticky === true || col.sticky === 1) {
        this.mainColumnDimenstions[col.field_id] = [];
        this.mainColumnDimenstions[col.field_id].checked = true;
        this.mainColumnDimenstions[col.field_id].sticky = true;
      } else {
        if (this.commonColumnDimensions[index].checked === true || this.commonColumnDimensions[index].checked === 1) {
          this.mainColumnDimenstions[col.field_id] = [];
          this.mainColumnDimenstions[col.field_id].checked = true;
          this.mainColumnDimenstions[col.field_id].sticky = false;
        } else {
          this.mainColumnDimenstions[col.field_id] = [];
          this.mainColumnDimenstions[col.field_id].checked = false;
          this.mainColumnDimenstions[col.field_id].sticky = false;
        }
      }
    });
  }

  saveFieldSelection() {
    this.loaderService.isLoading.next(true);
    this.userrole = 'BA';
    this.dashBoard.saveColumnFieldsSevice(this.stickyColumnDimensions, this.commonColumnDimensions, this.userrole).subscribe(res => {
      this.getColumnDisplay();
      this.loaderService.isLoading.next(false);
    }, err => {
      this.loaderService.isLoading.next(false);
    });
  }

  revertFieldSelection() {
    if (this.currentColumnSelection) {
      this.stickyColumnDimensions = this.currentColumnSelection['sticky'];
      this.commonColumnDimensions = this.currentColumnSelection['common'];
      this.columnDisplay();
    }
  }

  newDate(date) {
    return this.datePip.transform(date, 'dd/MM/yyyy HH:mm');
  }

  public onSelectedKeysChange(e) {
    const len = this.mySelection.length;

    if (len === 0) {
      this.isChecked = false;
      this.selectAllState = 'unchecked';
    } else if (len > 0 && len < this.gridData.data.length) {
      this.isChecked = true;
      this.selectAllState = 'indeterminate';
    } else {
      this.isChecked = true;
      this.selectAllState = 'checked';
    }
  }

  public onSelectAllChange(checkedState: SelectAllCheckboxState) {
    if (checkedState === 'checked') {
      this.mySelection = this.gridData.data.map((item) => item.workflow_id);
      this.selectAllState = 'checked';
    } else {
      this.mySelection = [];
      this.selectAllState = 'unchecked';
    }
  }

  proceedToDelete() {
    this.modalRef.hide();
    this.dashBoard.deleteMandates(this.mySelection).subscribe(res => {
      this.removeSelection();
      this.getAllMandatess();
      this.toastr.success('Deleted successfully!', 'Delete Records!');
    }, err => {
      this.toastr.error('Something went wrong! try again later', 'Delete Records!');
    });
  }

  removeSelection() {
    this.mySelection = [];
    this.isChecked = false;
    this.selectAllState = 'unchecked';
  }

  getComments() {
    this.dashBoard.getComments(this.workId).subscribe(responsedata => {
      this.filteredData = responsedata.dashBoardDataList;
      console.log(this.filteredData);
    });
  }

  addComment(value: string) {
      this.comment = value;
      this.userid = this.workId;
      this.role = 'BA';
      this.dashBoard.addComment(this.comment, this.role, this.userid).subscribe(addedComment => {
        console.log(addedComment);
        this.comment = '';
        this.getComments();
   });
  }

  onAction(action: DialogAction){
    if (action.text === 'Add comment') {
      this.addComment(this.comment);
      this.opened = true;
    }
    this.opened = false;
  }

  close() {
    this.opened = false;
  }

  copyInputMessage(inputElement) {
    inputElement.select();
    document.execCommand('copy');
    inputElement.setSelectionRange(0, 0);
  }

}
