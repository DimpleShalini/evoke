import { Component, OnInit } from '@angular/core';
import { } from '../../services/user.service';
import { BulkuploadSharedData } from '../../services/bulkUpload.sharedData.service'
import { BulkuploadService } from '../../services/bulkupload.service';
import { Router } from '@angular/router';
@Component({
  selector: 'bulkmandate',
  templateUrl: './bulkmandate.component.html',
  styleUrls: ['./bulkmandate.component.scss']
})
export class BulkmandateComponent {


  mandates: any;
  failedMandates: any;
  allEntities: any;
  succesMandatesFinal: any;
  failedMandatesCount: any;
  allMandatesCount: any;
  private obj: any;
  constructor(private bulkuploadSharedData: BulkuploadSharedData,
    private router: Router,
    private bulkUpload: BulkuploadService) {
    this.mandates = this.bulkuploadSharedData.getMandateData();
    this.failedMandates = this.mandates.failMandates;
    this.failedMandatesCount = this.failedMandates.length;
    this.allEntities = this.mandates.allMandates;
    this.allMandatesCount = this.allEntities.length;
    this.succesMandatesFinal = this.mandates.succesMandatesFinal;
  }


  errorMandates() {

    this.router.navigate(['/bulkmandate/errorMandates'])
    this.bulkuploadSharedData.setMandateData(this.mandates)

  }

  allMandates() {

    this.router.navigate(['/bulkmandate/allMandates'])
    this.bulkuploadSharedData.setMandateData(this.mandates)

  }

  createMandates() {

    this.obj = JSON.parse(JSON.stringify(this.succesMandatesFinal));

    let finalMandates = {
      mandates: this.obj
    }

    this.bulkUpload.createMandates(finalMandates).subscribe(response => {
      this.router.navigate(['/kendo']);
    })


  }


}