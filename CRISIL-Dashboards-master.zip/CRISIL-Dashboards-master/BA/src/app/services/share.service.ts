import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Observable } from 'rxjs/internal/Observable';

@Injectable()
export class DataService {
  private _headerSearch: BehaviorSubject<any> = new BehaviorSubject<any>([]);
  search: Observable<any> = this._headerSearch.asObservable();

  constructor() { }

  searchHeader(filter: any) {
    this._headerSearch.next(filter);
  }

}