import { Injectable } from '@angular/core';
// import { Observable, of, throwError } from 'rxjs';
import {
  HttpClient,
  HttpResponse,
  HttpHeaders,
  HttpHandler,
  HttpErrorResponse
} from '@angular/common/http';
import { SettingsService } from './settings.service';
import { Observable, forkJoin } from 'rxjs';


@Injectable()
export class DashboardService {
  private API_ALL_MANDATES_URL = '/extension/smekpi';
  private API_GET_COLUMN_FIELDS = '/extension/smekpi';
  private API_SET_COLUMN_FIELDS = '/extension/smedashboard';
  private API_GET_AUTO_PRODUCT = '/extension/getMasterData';
  private API_GET_COLUMN_DATA = '/extension/smedashboard?f=getbamandates';
  private API_GET_MANDATES_URL_FILTERS = '/extension/smedashboard?f=getbamandatesbystatus';
  private API_GET_EXCEL_MANDATES = '/extension/smedashboard?f=getbamandatesforexcel';
  private API_POST_COMMENTS = '/extension/smedashboard?f=savecomments';
  private API_GET_COMMENTS = '/extension/smekpi';


  constructor(
    private http: HttpClient,
    private settingsService: SettingsService) {

  }

  getAllMandatesWithFilters(filter?, page?, sort?) {
    //    POST /api/v1/purchaseorder
    return this.http.post<any>(this.settingsService.getBonitaApiBaseUrl() + this.API_GET_COLUMN_DATA , {
      filter: filter,
      page: page,
      sort: sort
    });
  }

  deleteMandates(rec) {
    return this.http.get<any>(this.settingsService.getBonitaApiBaseUrl() + this.API_ALL_MANDATES_URL + '?c=0&p=10&f=deletemandates&ids='+ rec.join());
  }

  onProductAutoComplete(obj) {
    return this.http.post<any>(
      this.settingsService.getBonitaApiBaseUrl() +
        this.API_GET_AUTO_PRODUCT + '?f=product',
      obj,
      { observe: 'response' }
    );
  }

   onInstitutionAutoComplete(obj) {
    return this.http.post<any>(
      this.settingsService.getBonitaApiBaseUrl() +
        this.API_GET_AUTO_PRODUCT + '?f=institution',
      obj,
      { observe: 'response' }
    );
   }

   onBillingCompanyAutoComplete(obj) {
    return this.http.post<any>(
      this.settingsService.getBonitaApiBaseUrl() +
        this.API_GET_AUTO_PRODUCT + '?f=bacompany',
      obj,
      { observe: 'response' }
    );
   }

   onBillingCompanyContactAutoComplete(obj) {
    return this.http.post<any>(
      this.settingsService.getBonitaApiBaseUrl() +
        this.API_GET_AUTO_PRODUCT + '?f=bacompanycontact',
      obj,
      { observe: 'response' }
    );
   }

  getColumnFieldService() {
    return this.http.get(
      this.settingsService.getBonitaApiBaseUrl() +
        this.API_GET_COLUMN_FIELDS +
        '?c=0&f=getdashboardfields&p=BA'
    );
  }

  saveColumnFieldsSevice(leftColumn, rightColumn, userrole) {
    return this.http.post<any>(
      this.settingsService.getBonitaApiBaseUrl() +
        this.API_SET_COLUMN_FIELDS +
        '?c=0&f=saveconfiguration&p=BA',
        {'dashboardFieldMenu':leftColumn, 'rightDashboardFieldMenu': rightColumn, 'userrole':userrole },
      { observe: 'response' }
    );
  }

  getMadatesCount() {
    return this.http.get<any>(this.settingsService.getBonitaApiBaseUrl() + this.API_ALL_MANDATES_URL + '?c=0&p=0&f=getOverAllCountsForBA');
  }

  getMandatesByFilter(filter?, page?, mandateStatus?, sort?) {
    return this.http.post<any>(this.settingsService.getBonitaApiBaseUrl() + this.API_GET_MANDATES_URL_FILTERS,
      { filter, page, mandateStatus, sort });
  }

  getProcessIdToRedirectParent() {
    return this.http.get('/bonita/API/bpm/process?f=name=SME Process&p=0&c=1&o=version%20desc&f=activationState=ENABLED');
  }

  fetchExcelData(data) {
    if (data.length > 0 ) {
      return this.http.post(this.settingsService.getBonitaApiBaseUrl() + this.API_GET_EXCEL_MANDATES, { requestIds: data.join()});
    } else {
      return this.http.post(this.settingsService.getBonitaApiBaseUrl() + this.API_GET_EXCEL_MANDATES, {});
    }
  }

  globalHeaderSearch(globalSearch) {
    return this.http.post<any>(
      this.settingsService.getBonitaApiBaseUrl() +
        this.API_SET_COLUMN_FIELDS +
        '?f=getbamandatesforglobalsearch',
        {
          'filter':{
             'filters':[
                {
                   'filters':[
                      {
                         'field': '',
                         'operator':'',
                         'value': ''
                      }

                   ]

                },

             ],
             'logic':'and'
          },
          'page':{
             'page':1,
             'pageSize':10
          },
          'sort':{
             'dir':'',
             'field':''
          },
       'columnName': globalSearch.searchFilter ? globalSearch.searchFilter : '',
       'searchString': globalSearch.searchWord
       },
      { observe: 'response' }
    );
  }

  getComments(workflow_id) {
    return this.http.get<any>(this.settingsService.getBonitaApiBaseUrl() + this.API_GET_COMMENTS + '?f=getcomments&c='+workflow_id+'&p=BA');
  }

  addComment(Comment, Role, id) {
    return this.http.post(this.settingsService.getBonitaApiBaseUrl() + this.API_POST_COMMENTS, {
      comment : Comment,
      userRole : Role,
      workflow_id : id
    });
  }

}
