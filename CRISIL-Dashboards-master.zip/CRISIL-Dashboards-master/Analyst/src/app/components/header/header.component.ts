import { Component, OnInit } from '@angular/core';

import { CookieService } from 'ngx-cookie-service';
import { UserService, User } from '../../services/user.service';
import { DataService } from '../../services/share.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  currentUser: User = null;
  errorMessage = '';
  isLoading = true;
  searchbox = {
    searchFilter: 'all',
    searchWord: ''
  };

  constructor(
    private data: DataService,
    private userService: UserService,
    public cookieService: CookieService) { }

  ngOnInit() {
    this.userService.loggedInUser.subscribe(
      data => {
        this.currentUser = data ;
        this.isLoading = false;
      });
  }

  doSearch() {
    this.data.searchHeader(this.searchbox);
  }

  logout() {
    this.cookieService.deleteAll();
    const url = window.location.origin + '/bonita/login.jsp';
    window.parent.location.replace(url);
  }

}
