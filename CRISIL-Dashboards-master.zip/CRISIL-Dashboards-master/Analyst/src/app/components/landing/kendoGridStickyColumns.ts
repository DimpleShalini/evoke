export const stickyColumnDimensions: any = [
    {
        column_type: 'left',
        field_name: 'Mandate id',
        field_id: 'mandate_id',
        status: false,
        disabled: false,
        checked: false,
        sticky: false
    },
    {
        column_type: 'left',
        field_name: 'Allocation date',
        field_id: 'allocation_date',
        status: false,
        disabled: false,
        checked: false,
        sticky: false
    },
    {
        column_type: 'left',
        field_name: 'Institution name',
        field_id: 'institution_name',
        status: true,
        disabled: false,
        checked: true,
        sticky: true
    },
    {
        column_type: 'left',
        field_name: 'Product',
        field_id: 'product',
        status: false,
        disabled: false,
        checked: false,
        sticky: false
    },
    {
        column_type: 'left',
        field_name: 'Entity name',
        field_id: 'entity_name',
        status: true,
        disabled: false,
        checked: true,
        sticky: true
    },
    {
        column_type: 'left',
        field_name: 'Team1 Analyst',
        field_id: 'team1_analyst_name',
        status: false,
        disabled: false,
        checked: false,
        sticky: false
    },
    {
        column_type: 'left',
        field_name: 'Team2 Analyst',
        field_id: 'team2_analyst_name',
        status: false,
        disabled: false,
        checked: false,
        sticky: false
    },
    {
        column_type: 'left',
        field_name: 'Team1 TL',
        field_id: 'team1_tl_name',
        status: false,
        disabled: false,
        checked: false,
        sticky: false
    },
    {
        column_type: 'left',
        field_name: 'Team2 TL',
        field_id: 'team2_tl_name',
        status: false,
        disabled: false,
        checked: false,
        sticky: false
    },
    {
        column_type: 'left',
        field_name: 'Main Status',
        field_id: 'case_current_status',
        status: false,
        disabled: false,
        checked: false,
        sticky: false
    },
    {
        column_type: 'left',
        field_name: 'Sub Status',
        field_id: 'sub_status',
        status: false,
        disabled: false,
        checked: false,
        sticky: false
    },
    // {
    //     column_type: 'left',
    //     field_name: 'Case Status Metrics',
    //     field_id: 'case_status_metrics',
    //     status: false,
    //     disabled: false,
    //     checked: false,
    //     sticky: false
    // },

    {
        column_type: 'left',
        field_name: 'Urgent Case',
        field_id: 'urgent_case',
        status: false,
        disabled: false,
        checked: false,
        sticky: false
    }
];

export const commonColumnDimensions: any = [
    {
        column_type: 'right',
        field_name: 'Mandate id',
        field_id: 'mandate_id',
        status: false,
        disabled: false,
        checked: true,
        sticky: false
    },
    {
        column_type: 'right',
        field_name: 'Allocation date',
        field_id: 'allocation_date',
        status: false,
        disabled: false,
        checked: true,
        sticky: false
    },
    {
        column_type: 'right',
        field_name: 'Institution name',
        field_id: 'institution_name',
        status: false,
        disabled: true,
        checked: false,
        sticky: false
    },
    {
        column_type: 'right',
        field_name: 'Product',
        field_id: 'product',
        status: false,
        disabled: false,
        checked: true,
        sticky: false
    },
    {
        column_type: 'right',
        field_name: 'Entity name',
        field_id: 'entity_name',
        status: false,
        disabled: true,
        checked: false,
        sticky: false
    },
    {
        column_type: 'right',
        field_name: 'Team1 Analyst',
        field_id: 'team1_analyst_name',
        status: false,
        disabled: false,
        checked: true,
        sticky: false
    },
    {
        column_type: 'right',
        field_name: 'Team2 Analyst',
        field_id: 'team2_analyst_name',
        status: false,
        disabled: false,
        checked: true,
        sticky: false
    },
    {
        column_type: 'right',
        field_name: 'Team1 TL',
        field_id: 'team1_tl_name',
        status: false,
        disabled: false,
        checked: true,
        sticky: false
    },
    {
        column_type: 'right',
        field_name: 'Team2 TL',
        field_id: 'team2_tl_name',
        status: false,
        disabled: false,
        checked: true,
        sticky: false
    },
    {
        column_type: 'right',
        field_name: 'Main Status',
        field_id: 'case_current_status',
        status: false,
        disabled: false,
        checked: true,
        sticky: false
    },
    {
        column_type: 'right',
        field_name: 'Sub Status',
        field_id: 'sub_status',
        status: false,
        disabled: false,
        checked: true,
        sticky: false
    },
    // {
    //     column_type: 'right',
    //     field_name: 'Case Status Metrics',
    //     field_id: 'case_status_metrics',
    //     status: false,
    //     disabled: false,
    //     checked: true,
    //     sticky: false
    // },
    {
        column_type: 'right',
        field_name: 'Urgent Case',
        field_id: 'urgent_case',
        status: false,
        disabled: false,
        checked: true,
        sticky: false
    }
];
