import { Component, OnInit, ViewChild } from '@angular/core';
import { SortDescriptor, State,  CompositeFilterDescriptor, orderBy } from '@progress/kendo-data-query';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { DashboardService } from '../../services/dashboard.service';
import { Observable, throwError, of } from 'rxjs';
import { debounceTime, distinctUntilChanged, switchMap, map, catchError } from 'rxjs/operators';
import { LoaderService } from '../../loader.service';
import { ExcelServicesService } from '../../services/excel.service';

import { GridDataResult, SelectAllCheckboxState, PageChangeEvent } from '@progress/kendo-angular-grid';
import { ExcelExportData } from '@progress/kendo-angular-excel-export';
import * as XLSX from 'xlsx';
import * as FileSaver from 'file-saver';
const EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
const EXCEL_EXTENSION = '.xlsx';
import { ToastrService } from 'ngx-toastr';
import { DataService } from '../../services/share.service';
import { TabsetComponent } from 'ngx-bootstrap/tabs';
import { FormGroup, FormArray, FormControl } from '@angular/forms';
import { DialogService, DialogRef, DialogCloseResult } from '@progress/kendo-angular-dialog';
import { stickyColumnDimensions, commonColumnDimensions  } from './kendoGridStickyColumns';
import { WindowRef } from './window';

@Component({
  selector: "landing-component",
  templateUrl: './landing.component.html',
  styleUrls: ['./landing.component.scss'],
  providers: [WindowRef]

})
export class LandingComponent implements OnInit {
  @ViewChild('tabset', { static: true }) tabset: TabsetComponent;
  @ViewChild('dropdown1', null) public dropdown1: any;
  @ViewChild('dropdown2', null) public dropdown2: any;
  @ViewChild('dropdown3', null) public dropdown3: any;
  @ViewChild('dropdown4', null) public dropdown4: any;

  singleModuleSearch = {
    searchProductTypeText: '',
    searchInstituteText: '',
    searchBillingCompany: '',
    searchBillingCompanyContact: ''
  };
  public state: State = {
    skip: 0,
    take: 10,
    sort: [{
      field: 'entity_name',
      dir: 'asc'
    }],
    // Initial filter descriptor
    filter: {
      logic: 'and',
      filters: []
    }
  };
  overviewPage = { page: 1, pageSize: 10 };
  public gridData: GridDataResult;
  gridShow: string = 'all';
  modalRef: BsModalRef;
  stickyCount: number;
  usrData: any;
  statuses = [];

  mandatesCounts = {
    totalMandateCount: 0,
    allocatedtoteam1analyst: 0,
    team1awaited: 0,
    team1returned: 0,
    allocatedtoteam1tl: 0,
    team1tlawaited: 0,
    senttoteam2: 0,
    allocatedtoteam2analyst: 0,
    team2awaited: 0,
    team2returned: 0,
    allocatedtoteam2tl: 0,
    team2tlawaited: 0,
    senttoclient: 0
  };

  mainColumnDimenstions = {
    mandate_id          : { sticky: false, checked: true },
    entity_name         : { sticky: true,  checked: true },
    institution_name    : { sticky: true,  checked: true },
    product             : { sticky: false, checked: true },
    allocation_date     : { sticky: false, checked: true },
    team1_analyst_name  : { sticky: false, checked: true },
    team2_analyst_name  : { sticky: false, checked: true },
    team1_tl_name       : { sticky: false, checked: true },
    team2_tl_name       : { sticky: false, checked: true },
    case_current_status : { sticky: false, checked: true },
    sub_status          : { sticky: false, checked: true },
    // case_status_metrics : { sticky: false, checked: true },
    urgent_case         : { sticky: false, checked: true },
  };

  stickyColumnDimensions: any = stickyColumnDimensions;
  commonColumnDimensions: any = commonColumnDimensions;

  public mySelection: number[] = [];
  public selectAllState: SelectAllCheckboxState = 'unchecked';
  excel = [];
  isChecked: boolean = false;
  currentColumnSelection: any = [];
  datastring: any;
  hover: any;
  userRole: string; // AnalystTeam1, AnalystLead1, AnalystTeam2, AnalystLead2
  analystTeam1List = [];
  analystTeam2List = [];
  analystLead1List = [];
  analystLead2List = [];
  comment: string;
  workId: any;
  filteredData: any;
  dropdownOldVal: any;

  constructor(
    private loaderService: LoaderService,
    private dashBoard: DashboardService,
    private modalService: BsModalService,
    private excelService: ExcelServicesService,
    private toastr: ToastrService,
    private data: DataService,
    private dialogService: DialogService,
    private winRef: WindowRef) {

  }

  ngOnInit() {
    const role = this.winRef.nativeWindow.parent.location.href.split('=')[1];
    if (!role) {
      console.log('role not exists!');
    } else {
      this.userRole = role;
    }

    this.data.search.subscribe(searchFilter => {
      if (searchFilter.searchWord === '') {
        this.getAllMandatess();
      }
      if (searchFilter.searchWord) {
        this.globalSearchFilter(searchFilter);
      }
    });
    this.getUserList();
    this.getColumnDisplay();
    this.getAllMandatess();
  }

  getUserList() {
    this.dashBoard.getAnalystTeam1List().subscribe(
      result => {
        this.analystTeam1List = result.Groups;
      });
    this.dashBoard.getAnalystTeam2List().subscribe(
      result => {
        this.analystTeam2List = result.Groups;
      });
    this.dashBoard.getAnalystLead1List().subscribe(
      result => {
        this.analystLead1List = result.Groups;
      });
    this.dashBoard.getAnalystLead2List().subscribe(
      result => {
        this.analystLead2List = result.Groups;
      });
  }

  getColumnDisplay() {
    this.dashBoard.getColumnFieldService().subscribe(
      res => {
        if (res && res['dashboardFieldMenu'].length > 0) {
          this.currentColumnSelection['sticky'] = res['dashboardFieldMenu'];
          this.currentColumnSelection['common'] = res['rightDashboardFieldMenu'];
          this.stickyColumnDimensions = res['dashboardFieldMenu'];
          this.commonColumnDimensions = res['rightDashboardFieldMenu'];
          // this.columnSegragate(res['dashboardFieldMenu']);
          this.columnDisplay();
        } else {
          this.currentColumnSelection = this.stickyColumnDimensions;
          this.columnDisplay();
        }
        this.currentColumnSelection['sticky'] = this.stickyColumnDimensions;
        this.currentColumnSelection['common'] = this.commonColumnDimensions;
        this.checkColumnCount();
      }, error => {
        this.currentColumnSelection['sticky'] = this.stickyColumnDimensions;
        this.currentColumnSelection['common'] = this.commonColumnDimensions;
        this.columnDisplay();
      });
  }

  columnDisplay() {
    this.stickyColumnDimensions.filter((col, index) => {
      if (col.sticky === true || col.sticky === 1) {
        this.mainColumnDimenstions[col.field_id] = [];
        this.mainColumnDimenstions[col.field_id].checked = true;
        this.mainColumnDimenstions[col.field_id].sticky = true;
      } else {
        if (this.commonColumnDimensions[index].checked === true || this.commonColumnDimensions[index].checked === 1) {
          this.mainColumnDimenstions[col.field_id] = [];
          this.mainColumnDimenstions[col.field_id].checked = true;
          this.mainColumnDimenstions[col.field_id].sticky = false;
        } else {
          this.mainColumnDimenstions[col.field_id] = [];
          this.mainColumnDimenstions[col.field_id].checked = false;
          this.mainColumnDimenstions[col.field_id].sticky = false;
        }
      }
    });
  }

  getMandatesCount() {
    this.dashBoard.getMadatesCount().subscribe(count => {
      if (count && count.mandatesCounts) {
        this.mandatesCounts.totalMandateCount = count.mandatesCounts.totalMandateCount || 0;
        this.mandatesCounts.allocatedtoteam1analyst = count.mandatesCounts.allocatedtoteam1analyst || 0;
        this.mandatesCounts.team1awaited = count.mandatesCounts.team1awaited || 0;
        this.mandatesCounts.team1returned = count.mandatesCounts.team1returned || 0;
        this.mandatesCounts.allocatedtoteam1tl = count.mandatesCounts.allocatedtoteam1tl || 0;
        this.mandatesCounts.team1tlawaited = count.mandatesCounts.team1tlawaited || 0;
        this.mandatesCounts.senttoteam2 = count.mandatesCounts.senttoteam2 || 0;
        this.mandatesCounts.allocatedtoteam2analyst = count.mandatesCounts.allocatedtoteam2analyst || 0;
        this.mandatesCounts.team2awaited = count.mandatesCounts.team2awaited || 0;
        this.mandatesCounts.team2returned = count.mandatesCounts.team2returned || 0;
        this.mandatesCounts.allocatedtoteam2tl = count.mandatesCounts.allocatedtoteam2tl || 0;
        this.mandatesCounts.team2tlawaited = count.mandatesCounts.team2tlawaited || 0;
        this.mandatesCounts.senttoclient = count.mandatesCounts.senttoclient || 0;
      }
    });
  }

  getAllMandatess() {
    this.loaderService.isLoading.next(true);
    this.getMandatesCount();

    if (this.gridShow === 'all') {
      this.dashBoard.getAllMandatesWithFilters(this.state.filter, this.overviewPage, this.state.sort, this.userRole)
      .subscribe(res => {
        this.gridData = {
          data: res.dashBoardDataList || [],
          total: res.allMandatesCount || 0
        };

        this.statuses = res.statusMap ? res.statusMap : [];
        this.loaderService.isLoading.next(false);
      }, err => {
        this.gridData = {
          data: [],
          total: 0
        };
        this.loaderService.isLoading.next(false);
      });
    } else {
      const mandateStatus = this.gridShow;
      this.dashBoard.getMandatesByFilter(this.state.filter, this.overviewPage, this.state.sort, this.userRole, mandateStatus).subscribe(
        result => {
          this.gridData = {
            data: result.dashBoardDataList || [],
            total: result.allMandatesCount || 0
          };
          this.loaderService.isLoading.next(false);
        }, err => {
          this.gridData = {
            data: [],
            total: 0
          };
          this.loaderService.isLoading.next(false);
        });
    }
  }

  changeViewState(section) {
    this.gridShow = section;
    this.overviewPage = { page: 1, pageSize: 10 };
    this.state = {
      skip: 0,
      take: 10,
      sort: [{
        field: 'entity_name',
        dir: 'asc'
      }],
      filter: {
        logic: 'and',
        filters: []
      }
    };

    if (section === 'all') {
      this.getAllMandatess();
    } else {
      const mandateStatus = section;
      this.loaderService.isLoading.next(true);
      this.getMandatesCount();

      this.dashBoard.getMandatesByFilter(this.state.filter, this.overviewPage, this.state.sort, this.userRole, mandateStatus).subscribe(
        result => {
          this.gridData = {
            data: result.dashBoardDataList || [],
            total: result.allMandatesCount || 0
          };
          this.loaderService.isLoading.next(false);
        }, err => {
          this.gridData = {
            data: [],
            total: 0
          };
          this.loaderService.isLoading.next(false);
      });
    }
  }

  updateCheckedOptions(options, event, type?, ind?) {
    if (type && type === 'sticky') {
      this.stickyColumnDimensions[ind].sticky = !this.stickyColumnDimensions[ind].sticky;
      this.stickyColumnDimensions[ind].checked = !this.stickyColumnDimensions[ind].checked;
      this.stickyColumnDimensions[ind].status = !this.stickyColumnDimensions[ind].status;
      if (this.stickyColumnDimensions[ind].checked) {
        if (this.commonColumnDimensions[ind].checked) {
          this.commonColumnDimensions[ind].checked = !this.commonColumnDimensions[ind].checked;
        }
        this.commonColumnDimensions[ind].disabled = true;
      } else {
        this.commonColumnDimensions[ind].disabled = false;
        this.commonColumnDimensions[ind].checked = false;
      }

      this.checkColumnCount();
    } else {
      this.commonColumnDimensions[ind].checked = !this.commonColumnDimensions[ind].checked;
      this.commonColumnDimensions[ind].status = !this.commonColumnDimensions[ind].status;
    }
  }

  checkColumnCount() {
    this.stickyCount = 0;
    this.stickyColumnDimensions.forEach(item => {
      if (item.checked) {
        this.stickyCount = this.stickyCount + 1;
      }
    });
    if (this.stickyCount >= 2) {
      this.stickyColumnDimensions.forEach(item => {
        if (!item.checked) {
          item.disabled = true;
        }
      });
    } else {
      this.stickyColumnDimensions.forEach(item => {
        if (!item.checked) {
          item.disabled = false;
        }
      });
    }
  }

  public onSelectedKeysChange(e) {
    const len = this.mySelection.length;

    if (len === 0) {
      this.isChecked = false;
      this.selectAllState = 'unchecked';
    } else if (len > 0 && len < this.gridData.data.length) {
      this.isChecked = true;
      this.selectAllState = 'indeterminate';
    } else {
      this.isChecked = true;
      this.selectAllState = 'checked';
    }
  }

  public onSelectAllChange(checkedState: SelectAllCheckboxState) {
    if (checkedState === 'checked') {
      this.mySelection = this.gridData.data.map((item) => item.workflow_id);
      this.selectAllState = 'checked';
    } else {
      this.mySelection = [];
      this.selectAllState = 'unchecked';
    }
  }

  public filterChange(filter: CompositeFilterDescriptor): void {
    this.overviewPage.page = 1;
    this.overviewPage.pageSize = 10;
    this.state.skip = 0;
    this.state.take = 10;
    this.state.filter = filter;
    this.getAllMandatess();
  }

  public sortChange(sort: SortDescriptor[]): void {
    this.state.sort = sort;
    this.getAllMandatess();
  }

  public pageChange({ skip, take }: PageChangeEvent): void {
    this.state.skip = skip;
    this.state.take = take;
    this.overviewPage.page = skip / 10 + 1;
    this.overviewPage.pageSize = take;
    this.getAllMandatess();
  }

  public getFrommServerData(): any {
    let selectedIds = [];
    if (this.mySelection.length > 0) {
      selectedIds = this.mySelection;
    }
    this.dashBoard.fetchExcelData(selectedIds, this.userRole).subscribe(
      records => {
        this.excel = [];
        if (records && records['dashBoardDataList'].length > 0) {
          records['dashBoardDataList'].forEach(row => {
            this.excel.push(row);
          });
          setTimeout(() => {
            this.excelService.exportAsExcelFile(this.excel, this.userRole);
          }, 800);
        } else {
          this.toastr.warning('No records available to export', 'Excel export!');
        }
    });
  }

  openModal(modal, type, dataItem) {
    if (type === 'delete') {
      if (this.mySelection && this.mySelection.length < 1) {
        return;
      }
    }
    this.singleModuleSearch.searchInstituteText = '';
    this.singleModuleSearch.searchProductTypeText = '';
    setTimeout(() => {
      this.modalRef = this.modalService.show(modal, { keyboard: false, ignoreBackdropClick: true });
    }, 400);
    if (type === 'configureColumns') {
      this.checkColumnCount();
    }
    if (type === 'cmnt') {
      this.workId = dataItem.workflow_id;
      this.getComments();
    }
  }

  getComments() {
    this.dashBoard.getComments(this.workId).subscribe(responsedata => {
      this.filteredData = responsedata.dashBoardDataList;
    });
  }

  addComment(value: string) {
    this.comment = value;
    this.dashBoard.addComment(this.comment, this.userRole, this.workId).subscribe(
      addedComment => {
        this.comment = '';
        this.getComments();
      });
  }

  openDropdown(oldval) {
    this.dropdownOldVal = oldval;
  }

  setDropdown(type) {
    switch (type) {
      case 'T1A':
        this.dropdown1.writeValue(this.dropdownOldVal);
        break;
      case 'T2A':
        this.dropdown2.writeValue(this.dropdownOldVal);
        break;
      case 'T1TL':
        this.dropdown3.writeValue(this.dropdownOldVal);
        break;
      case 'T2TL':
        this.dropdown4.writeValue(this.dropdownOldVal);
        break;
    }
  }

  selectionChange(item, dataItem, type) {
    const dialog: DialogRef = this.dialogService.open({
      title: 'Please confirm',
      content: 'Do you want to proceed with the change ?',
      actions: [
        { text: 'Cancel' },
        { text: 'Confirm', primary: true }
      ],
      width: 400,
      height: 140,
      minWidth: 250
    });

    dialog.result.subscribe((result) => {
      if (result instanceof DialogCloseResult) {
        this.setDropdown(type);
      } else {
        console.log('action', result);
        if (result.text === 'Confirm') {
          this.dashBoard.assignTaskToUser(type, item.userId, item.userName, dataItem.mandate_id).subscribe(
            result => {
              console.log(result);
            });
        }
        if (result.text === 'Cancel') {
          this.setDropdown(type);
        }
      }
    });
  }

  saveFieldSelection() {
    this.loaderService.isLoading.next(true);
    this.dashBoard.saveColumnFieldsSevice(this.stickyColumnDimensions, this.commonColumnDimensions).subscribe(res => {
      console.log(res);
      this.getColumnDisplay();
      this.loaderService.isLoading.next(false);
    }, err => {
      this.loaderService.isLoading.next(false);
    });
  }

  revertFieldSelection() {
    if (this.currentColumnSelection) {
      this.stickyColumnDimensions = this.currentColumnSelection['sticky'];
      this.commonColumnDimensions = this.currentColumnSelection['common'];
      this.columnDisplay();
    }
  }

  globalSearchFilter(searchFilter) {
    this.loaderService.isLoading.next(true);
    this.dashBoard.globalHeaderSearch(searchFilter, this.userRole).subscribe(result => {
      this.gridData = {
        data: result['dashBoardDataList'] || [],
        total: result['allMandatesCount'] || 0
      };
      this.tabset.tabs[0].active = true;
      this.gridShow = 'all';
      this.loaderService.isLoading.next(false);
    }, err => {
      this.gridData = {
        data: [],
        total: 0
      };
      this.loaderService.isLoading.next(false);
    });
  }

  redirectToParentBonita() {
    this.dashBoard.getProcessIdToRedirectParent().subscribe(process => {
      console.log(process, '', process);
      if (process && process[0]) {
        window.location.href = '/bonita/portal/resource/process/SME%20Process/1.0/content/?id=' + process[0].id + '&locale=en&mode=app&productName=' + this.singleModuleSearch.searchProductTypeText + '&instituteName=' + this.singleModuleSearch.searchInstituteText + '&bacontact=' + this.singleModuleSearch.searchBillingCompanyContact + '&bacompnay=' + this.singleModuleSearch.searchBillingCompany + '&test=abcc';
      }
    });
  }

  proceedToDelete() {
    this.modalRef.hide();
    this.dashBoard.deleteMandates(this.mySelection).subscribe(res => {
      this.removeSelection();
      this.getMandatesCount();
      this.getAllMandatess();
      this.toastr.success('Deleted successfully!', 'Delete Records!');
    }, err => {
      this.toastr.error('Something went wrong! try again later', 'Delete Records!');
    });
  }

  removeSelection() {
    this.mySelection = [];
    this.selectAllState = 'unchecked';
  }

  // validateMandate() {
  //   console.log(this.datastring);
  //   this.bulkUploadService.validateMandates(this.datastring).subscribe(response => {
  //     console.log(response);
  //     this.bulkUploadSharedData.setMandateData(response), () => { };
  //     this.modalRef.hide();
  //     this.router.navigate(['/bulkmandate']);
  //   });
  // }

  // uploadFile(ev) {

  //   this.datastring = {};
  //   this.usrData = {
  //     'Product Name': this.singleModuleSearch.searchProductTypeText,
  //     'Institution Name': this.singleModuleSearch.searchInstituteText,
  //     'Billing Company': this.singleModuleSearch.searchBillingCompany,
  //     'Billing Company Contact': this.singleModuleSearch.searchBillingCompanyContact
  //   };

  //   let workBook = null;
  //   let jsonData = null;
  //   const reader = new FileReader();
  //   const file = ev.target.files[0];
  //   let dataObj = [];
  //   reader.onload = (event) => {
  //     const data = reader.result;
  //     let datastr = [];
  //     workBook = XLSX.read(data, { type: 'binary' });
  //     jsonData = workBook.Sheets['Mandates'];
  //     let initial = XLSX.utils.sheet_to_json(jsonData, { raw: true, defval: null });
  //     if (initial.length > 0) {
  //       initial.forEach(function (row) {
  //         if (row['PRODUCT_TYPE'] && row['PRODUCT_CATEGORY']) {
  //           datastr.push(row);
  //         }
  //       });
  //     }
  //     dataObj = this.usrData;
  //     dataObj['mandates'] = datastr;
  //     this.datastring = JSON.stringify(dataObj);
  //     this.bulkUploadService.validateMandates(this.datastring).subscribe(response => {
  //       console.log(response);
  //       this.bulkUploadSharedData.setMandateData(response), () => { }
  //       this.modalRef.hide();
  //       this.router.navigate(['/bulkmandate']);
  //     });
  //   };
  //   reader.readAsBinaryString(file);
  // }

  showUserEntityLink(item) {
    if (this.userRole === 'AnalystTeam1') {
      return item.t1_analyst_task_link;
    } else if (this.userRole === 'AnalystLead1') {
      return item.t1_tl_task_link;
    } else if (this.userRole === 'AnalystTeam2') {
      return item.t2_analyst_task_link;
    } else if (this.userRole === 'AnalystLead2') {
      return item.t2_tl_task_link;
    } else {
      return '#';
    }
  }
}

function _window(): any {
  return window;
}
