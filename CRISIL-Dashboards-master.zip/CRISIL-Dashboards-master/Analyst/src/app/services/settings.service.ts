import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class SettingsService {
  private bonitaBaseUrl: string;

  constructor() {

  }

  getBonitaApiBaseUrl() {
    return '/bonita/API';
  }

  getBonitaBaseUrl() {
    if (!this.bonitaBaseUrl && window && window.location) {
      const paths = window.location.pathname.split('/', 2);
      this.bonitaBaseUrl = '/';
      if (paths && paths.length > 1) {
        this.bonitaBaseUrl += paths[1];
      }
    }
    return this.bonitaBaseUrl;
  }

}
