export const stickyColumnDimensions: any = [
    {
        column_type: 'left',
        field_name: 'Mandate id',
        field_id: 'mandate_id',
        status: false,
        disabled: false,
        checked: false,
        sticky: false
    },
    {
        column_type: 'left',
        field_name: 'Mandate Created date',
        field_id: 'mandate_created_date',
        status: false,
        disabled: false,
        checked: false,
        sticky: false
    },
    {
        column_type: 'left',
        field_name: 'Institution name',
        field_id: 'institution_name',
        status: true,
        disabled: false,
        checked: true,
        sticky: true
    },
    {
        column_type: 'left',
        field_name: 'BD',
        field_id: 'bd_name',
        status: false,
        disabled: false,
        checked: false,
        sticky: false
    },
    {
        column_type: 'left',
        field_name: 'Entity name',
        field_id: 'entity_name',
        status: true,
        disabled: false,
        checked: true,
        sticky: true
    },
    {
        column_type: 'left',
        field_name: 'Main case status',
        field_id: 'case_current_status',
        status: false,
        disabled: false,
        checked: false,
        sticky: false
    },
    {
        column_type: 'left',
        field_name: 'Cordination Case status',
        field_id: 'coordination_case_status',
        status: false,
        disabled: false,
        checked: false,
        sticky: false
    },
    {
        column_type: 'left',
        field_name: 'ISME Case Sub Status',
        field_id: 'workflow_status',
        status: false,
        disabled: false,
        checked: false,
        sticky: false
    },
    {
        column_type: 'left',
        field_name: 'TL',
        field_id: 'tl',
        status: false,
        disabled: false,
        checked: false,
        sticky: false
    },
    {
        column_type: 'left',
        field_name: 'Analyst',
        field_id: 'analyst',
        status: false,
        disabled: false,
        checked: false,
        sticky: false
    },
    {
        column_type: 'left',
        field_name: 'Credit exposure by bank',
        field_id: 'credit_exposure_by_bank',
        status: false,
        disabled: false,
        checked: false,
        sticky: false
    }
];

export const commonColumnDimensions: any = [
    {
        column_type: 'right',
        field_name: 'Mandate id',
        field_id: 'mandate_id',
        status: false,
        disabled: false,
        checked: true,
        sticky: false
    },
    {
        column_type: 'right',
        field_name: 'Mandate Created date',
        field_id: 'mandate_created_date',
        status: false,
        disabled: false,
        checked: true,
        sticky: false
    },
    {
        column_type: 'right',
        field_name: 'Institution name',
        field_id: 'institution_name',
        status: false,
        disabled: false,
        checked: false,
        sticky: false
    },
    {
        column_type: 'right',
        field_name: 'BD',
        field_id: 'bd_name',
        status: false,
        disabled: false,
        checked: true,
        sticky: false
    },
    {
        column_type: 'right',
        field_name: 'Entity name',
        field_id: 'entity_name',
        status: false,
        disabled: false,
        checked: false,
        sticky: false
    },
    {
        column_type: 'right',
        field_name: 'Main case status',
        field_id: 'case_current_status',
        status: false,
        disabled: false,
        checked: true,
        sticky: false
    },
    {
        column_type: 'right',
        field_name: 'Cordination Case status',
        field_id: 'coordination_case_status',
        status: false,
        disabled: false,
        checked: true,
        sticky: false
    },
    {
        column_type: 'right',
        field_name: 'ISME Case Sub Status',
        field_id: 'workflow_status',
        status: false,
        disabled: false,
        checked: true,
        sticky: false
    },
    {
        column_type: 'right',
        field_name: 'TL',
        field_id: 'tl',
        status: false,
        disabled: false,
        checked: true,
        sticky: false
    },
    {
        column_type: 'right',
        field_name: 'Analyst',
        field_id: 'analyst',
        status: false,
        disabled: false,
        checked: true,
        sticky: false
    },
    {
        column_type: 'right',
        field_name: 'Credit exposure by bank',
        field_id: 'credit_exposure_by_bank',
        status: false,
        disabled: false,
        checked: true,
        sticky: false
    }
];
