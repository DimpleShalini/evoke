import { BrowserModule } from '@angular/platform-browser';
import { Routes, RouterModule } from '@angular/router';
import { HTTP_INTERCEPTORS, HttpClientModule} from '@angular/common/http';
import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AngularFontAwesomeModule } from 'angular-font-awesome';
// import { AppRoutingModule } from './app-routing.module';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
// import { DashboardComponent } from './components/dashboard/dashboard.component';
// import { bulkmandateComponent } from './components/bulkmandate/bulkmandate.component';
// import { TabsModule } from 'ngx-bootstrap/tabs';
// import { ModalModule } from 'ngx-bootstrap/modal';
// import { HeaderComponent } from './components/header/header.component';
// import { InterceptorConfig } from './services/interceptor.config';
// import { SettingsService } from './services/settings.service';
// import { UserService } from './services/user.service';
// import { UserImpl } from './services/user.impl.service';
// import { DashboardService } from './services/dashboard.service';
// import { CookieService } from 'ngx-cookie-service';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';




@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    NgbModule,
    AngularFontAwesomeModule,
    HttpClientModule,
    BrowserAnimationsModule,
    FormsModule,
  ],
  providers: [
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
