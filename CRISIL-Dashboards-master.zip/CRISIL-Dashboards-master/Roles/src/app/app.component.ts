import { Component, TemplateRef, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {

  constructor(private http: HttpClient) { }
  Groups: {};
  selectedGrp = '';
  selectedName = '';
  private sub: any;
  roller = false;

  ngOnInit() {
    this.roller = false;
    this.getRoles();
  }

  getRoles() {
    this.roller = true;
    // this.http.get('/bonita/apps/selectrole/API/system/session/unusedId').subscribe(response => {
    //   if (response['user_name']) {
        this.http.get('/bonita/API/extension/userPermissions?f=getGroupsByUser').subscribe(res => {
          const newGrp =  res['Groups'];
          const keys = Object.keys(newGrp);
          if ( keys.length === 1) {
            // this.Groups = Object.keys(newGrp).map(key => ({name: key, link: newGrp[key]}));
            this.selectedGrp = newGrp[keys];
            this.selectedName = keys[0]; // this.Groups[0].name;
           // this.selectedGrp = this.Groups[0].link.BAGroup;
           // this.selectedName = this.Groups[0].name;
            console.log(this.selectedGrp, 'name', this.selectedName);
            this.redirectToPage();
          } else {
            this.Groups = Object.keys(newGrp).map(key => ({name: key, link: newGrp[key]}));
            this.roller = false;
          }
        });
    //   }
    // });
  }



  selectedValue(link, name) {
    this.selectedGrp = link;
    this.selectedName = name;
  }

  redirectToPage() {
    const url = window.location.origin + '/bonita' + this.selectedGrp + '?role=' + this.selectedName;
    window.parent.location.replace(url);
  }
}

