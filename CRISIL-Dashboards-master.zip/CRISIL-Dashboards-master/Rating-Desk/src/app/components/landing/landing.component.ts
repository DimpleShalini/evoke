import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { SortDescriptor, process, State, filterBy, FilterDescriptor, CompositeFilterDescriptor, orderBy } from '@progress/kendo-data-query';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { DashboardService } from '../../services/dashboard.service';
import { DatePipe } from '@angular/common';
import { Observable, throwError, of, Subscription } from 'rxjs';
import { debounceTime, distinctUntilChanged, switchMap, map, catchError } from 'rxjs/operators';
import { LoaderService } from '../../loader.service';
import { ExcelServicesService } from '../../services/excel.service';
import { BulkuploadService } from '../../services/bulkupload.service';
import { BulkuploadSharedData } from '../../services/bulkUpload.sharedData.service';
import {
  GridComponent,
  GridDataResult, SelectAllCheckboxState,
  DataStateChangeEvent, FilterService, PageChangeEvent, SelectableSettings, RowArgs
} from '@progress/kendo-angular-grid';
import { ExcelExportData } from '@progress/kendo-angular-excel-export';
import * as XLSX from 'xlsx';
import * as FileSaver from 'file-saver';
const EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
const EXCEL_EXTENSION = '.xlsx';
import { ToastrService } from 'ngx-toastr';
import { DataService } from '../../services/share.service';
import { TabsetComponent } from 'ngx-bootstrap/tabs';
import { FormGroup, FormArray, FormControl } from '@angular/forms';
import { DialogService, DialogRef, DialogCloseResult } from '@progress/kendo-angular-dialog';
import { CookieService } from 'ngx-cookie-service';
import { stickyColumnDimensions, commonColumnDimensions  } from './kendoGridStickyColumns';

@Component({
  selector: "landing-component",
  templateUrl: './landing.component.html',
  styleUrls: ['./landing.component.scss'],
  providers: [DatePipe]
})
export class LandingComponent implements OnInit, OnDestroy {
  @ViewChild('tabset', { static: true }) tabset: TabsetComponent;
  singleModuleSearch = {
    searchProductTypeText: '',
    searchInstituteText: '',
    searchBillingCompany: '',
    searchBillingCompanyContact: ''
  };
  public filter: CompositeFilterDescriptor;
  public state: State = {
    skip: 0,
    take: 10,
    sort: [{
      field: 'entity_name',
      dir: 'asc'
    }],
    // Initial filter descriptor
    filter: {
      logic: 'and',
      filters: []
    }
  };
  overviewfilter = { filters: [], logic: 'and' };
  overviewSort = [];
  overviewPage = { page: 1, pageSize: 10 };
  overViewData = { data: [], total: 0 };
  public checkboxOnly = false;
  public mode = 'multiple';
  public selectableSettings: SelectableSettings;
  public gridView: GridDataResult;
  public gridData: GridDataResult;
  gridShow: string = 'all';
  mandateSearch: string;
  modalRef: BsModalRef;
  showCommonColumns: any = [];
  stickyCount: number;
  pageSizeData = [
    { value: 10, id: 10 },
    { value: 25, id: 25 },
    { value: 50, id: 50 },
    { value: 100, id: 100 }
  ];
  usrData: any;

  statuses = [];

  mandatesCounts = {
    totalMandateCount: 0,
    allocatedtoteam1analyst: 0,
    team1awaited: 0,
    team1rejected: 0
  };
  mainColumnDimenstions = {
    mandate_id            : { sticky: false, checked: true },
    entity_name           : { sticky: true,  checked: true },
    institution_name      : { sticky: true,  checked: true },
    product               : { sticky: false, checked: true },
    allocation_date       : { sticky: false, checked: true },
    status                : { sticky: false, checked: true },
    sub_status            : { sticky: false, checked: true },
    team1_analyst_name    : { sticky: false, checked: true },
    team2_analyst_name    : { sticky: false, checked: true },
    team2_tl_name         : { sticky: false, checked: true },
    case_status_metrics   : { sticky: false, checked: true },
    urgent_case           : { sticky: false, checked: true },
  };

  stickyColumnDimensions: any = stickyColumnDimensions;
  commonColumnDimensions: any = commonColumnDimensions;

  public mySelection: number[] = [];
  public selectAllState: SelectAllCheckboxState = 'unchecked';
  isAllMandatesTab: boolean = true;
  excel = [];
  isBulkMandate = false;
  isChecked: boolean = false;
  currentColumnSelection: any = [];
  searchProductName: any;
  searchInstituteName: any;
  searchBillingComp: any;
  searchBillingCompContact: any;
  productId: string = '';
  institutionId: string = '';
  datastring: any;
  hover: any;
  loading: boolean = true;


  role: string;
  agendaNumber: any;
  private dropDownData: string[] = [];
  public formGroups: FormGroup = new FormGroup({ items: new FormArray([])});
  private subscription: Subscription;

  constructor(
    private loaderService: LoaderService,
    private dashBoard: DashboardService,
    private datePip: DatePipe,
    private modalService: BsModalService,
    private excelService: ExcelServicesService,
    private bulkUploadService: BulkuploadService,
    private bulkUploadSharedData: BulkuploadSharedData,
    private router: Router,
    private toastr: ToastrService,
    private data: DataService,
    private dialogService: DialogService,
    public cookieService: CookieService) {
      this.role = this.cookieService.get('userRole');
  }

  ngOnInit() {
    this.initialize();
    this.subscription = this.data.search.subscribe(searchBox => {
      if (searchBox.searchWord) {
        this.globalSearchFilter(searchBox);
      }
    });
    this.data.currentAgNo.subscribe(agNo => this.agendaNumber = agNo);
  }

  initialize() {
    this.getColumnDisplay();
    this.getMandatesCount();
    this.getAllMandatess();
  }

  getColumnDisplay() {
    this.dashBoard.getColumnFieldService().subscribe(
      res => {
        if (res && res['dashboardFieldMenu'].length > 0) {
          this.currentColumnSelection['sticky'] = res['dashboardFieldMenu'];
          this.currentColumnSelection['common'] = res['rightDashboardFieldMenu'];
          this.stickyColumnDimensions = res['dashboardFieldMenu'];
          this.commonColumnDimensions = res['rightDashboardFieldMenu'];
          this.columnDisplay();
        } else {
          this.currentColumnSelection = this.stickyColumnDimensions;
          this.columnDisplay();
        }
        this.currentColumnSelection['sticky'] = this.stickyColumnDimensions;
        this.currentColumnSelection['common'] = this.commonColumnDimensions;
        this.checkColumnCount();
      }, error => {
        this.currentColumnSelection['sticky'] = this.stickyColumnDimensions;
        this.currentColumnSelection['common'] = this.commonColumnDimensions;
        this.columnDisplay();
      });
  }

  columnDisplay() {
    this.stickyColumnDimensions.filter((col, index) => {
      if (col.sticky === true || col.sticky === 1) {
        // this.showCommonColumns.push(this.stickyColumnDimensions[index]);
        this.mainColumnDimenstions[col.field_id] = [];
        this.mainColumnDimenstions[col.field_id].checked = true;
        this.mainColumnDimenstions[col.field_id].sticky = true;
      } else {
        if (this.commonColumnDimensions[index].checked === true || this.commonColumnDimensions[index].checked === 1) {
          // this.showCommonColumns.push(this.stickyColumnDimensions[index]);
          this.mainColumnDimenstions[col.field_id] = [];
          this.mainColumnDimenstions[col.field_id].checked = true;
          this.mainColumnDimenstions[col.field_id].sticky = false;
        } else {
          this.mainColumnDimenstions[col.field_id] = [];
          this.mainColumnDimenstions[col.field_id].checked = false;
          this.mainColumnDimenstions[col.field_id].sticky = false;
        }
      }
    });

  }

  getMandatesCount() {
    this.dashBoard.getMadatesCount().subscribe(count => {
      if (count && count.mandatesCounts) {
        this.mandatesCounts.totalMandateCount = count.mandatesCounts.totalMandateCount ? count.mandatesCounts.totalMandateCount : 0;
        this.mandatesCounts.allocatedtoteam1analyst = count.mandatesCounts.allocatedtoteam1analyst ? count.mandatesCounts.allocatedtoteam1analyst : 0;
        this.mandatesCounts.team1awaited = count.mandatesCounts.team1awaited ? count.mandatesCounts.team1awaited : 0;
        this.mandatesCounts.team1rejected = count.mandatesCounts.team1rejected ? count.mandatesCounts.team1rejected : 0;
      }
    });
  }

  getAllMandatess() {
    // this.loaderService.isLoading.next(true);
    console.log(this.state);

    this.loading = true;
    const sortJson = {
      dir:
        this.overviewSort[0] && this.overviewSort[0].dir ? this.overviewSort[0].dir : '',
      field:
        this.overviewSort[0] && this.overviewSort[0].field ? this.overviewSort[0].field : ''
    };
    const overviewfiltercopy = JSON.parse(JSON.stringify(this.overviewfilter));
    this.gridShow = 'all';
    this.dashBoard.getAllMandatesWithFilters(overviewfiltercopy, this.overviewPage, sortJson || {})
      .subscribe(res => {

        console.log(res, 'response from mandate service');
        // this.gridData = res;
        this.gridData = {
          data: res.dashBoardDataList,
          total: res.allMandatesCount
        };

        this.statuses = res.statusMap ? res.statusMap : [];
        // this.loaderService.isLoading.next(false);
        this.loading = false;
      }, err => {
        this.gridData = {
          data: [],
          total: 0
        };
        // this.loaderService.isLoading.next(false);
        this.loading = false;
      });
  }

  changeViewState(section) {
    this.loading = true;
    console.log('adsadadsdsds', this.state);

    // this.loaderService.isLoading.next(true);
    if (section === 'all') {
      this.getAllMandatess();
    } else {
      const sortJson = {
        dir: this.overviewSort[0] && this.overviewSort[0].dir ? this.overviewSort[0].dir : '',
        field: this.overviewSort[0] && this.overviewSort[0].field ? this.overviewSort[0].field : '',
      };
      const overviewfiltercopy = JSON.parse(JSON.stringify(this.overviewfilter));
      const mandateStatus = section ? section : '';

      console.log(overviewfiltercopy, 'filter', mandateStatus, 'filter', this.overviewPage);
      console.log(section);
      this.gridShow = section;
      this.dashBoard.getMandatesByFilter(sortJson, this.overviewPage, mandateStatus).subscribe(result => {
        this.gridData = {
          data: result.dashBoardDataList,
          total: result.allMandatesCount
        };
        this.loading = false;
        // this.loaderService.isLoading.next(false);
      }, err => {
        this.gridData = {
          data: [],
          total: 0
        };
        this.loading = false;
        // this.loaderService.isLoading.next(false);
      });
    }
  }

  updateCheckedOptions(options, event, type?, ind?) {
    if (type && type === 'sticky') {
      this.stickyColumnDimensions[ind].sticky = !this.stickyColumnDimensions[ind].sticky;
      this.stickyColumnDimensions[ind].checked = !this.stickyColumnDimensions[ind].checked;
      this.stickyColumnDimensions[ind].status = !this.stickyColumnDimensions[ind].status;
      if (this.stickyColumnDimensions[ind].checked) {
        if (this.commonColumnDimensions[ind].checked) {
          this.commonColumnDimensions[ind].checked = !this.commonColumnDimensions[ind].checked;
        }
        this.commonColumnDimensions[ind].disabled = true;
      } else {
        this.commonColumnDimensions[ind].disabled = false;
        this.commonColumnDimensions[ind].checked = false;
      }

      this.checkColumnCount();
    } else {
      this.commonColumnDimensions[ind].checked = !this.commonColumnDimensions[ind].checked;
      this.commonColumnDimensions[ind].status = !this.commonColumnDimensions[ind].status;
    }
    // this.grid.refresh();
  }

  checkColumnCount() {
    this.stickyCount = 0;
    this.stickyColumnDimensions.forEach(item => {
      if (item.checked) {
        this.stickyCount = this.stickyCount + 1;
      }
    });
    if (this.stickyCount >= 2) {
      this.stickyColumnDimensions.forEach(item => {
        if (!item.checked) {
          item.disabled = true;
        }
      });
    } else {
      this.stickyColumnDimensions.forEach(item => {
        if (!item.checked) {
          item.disabled = false;
        }
      });
    }
  }

  public onSelectedKeysChange(e) {
    const len = this.mySelection.length;

    if (len === 0) {
      this.isChecked = false;
      this.selectAllState = 'unchecked';
    } else if (len > 0 && len < this.gridData.data.length) {
      // this.isChecked = true;
      this.selectAllState = 'indeterminate';
    } else {
      this.isChecked = true;
      this.selectAllState = 'checked';
    }
  }

  public onSelectAllChange(checkedState: SelectAllCheckboxState) {
    if (checkedState === 'checked') {
      this.mySelection = this.gridData.data.map((item) => item.workflow_id);
      this.selectAllState = 'checked';
    } else {
      this.mySelection = [];
      this.selectAllState = 'unchecked';
    }
  }

  public filterChange(filter: CompositeFilterDescriptor): void {
    this.overviewPage.page = 1;
    this.state.skip = 0;
    this.overviewfilter = filter;
    console.log(filter);
    this.getAllMandatess();
  }

  public sortChange(sort: SortDescriptor[]): void {
    this.state.sort = sort;
    // this.gridData = process(this.gridData, this.state);
    this.getAllMandatess();
  }

  public dataStateChange(state: DataStateChangeEvent): void {
    this.state = state;
    console.log('state', state);

    // this.gridData = process(this.gridData, this.state);
  }

  public pageChange({ skip, take }: PageChangeEvent): void {
    this.overviewPage.page = skip / 10 + 1;
    this.overviewPage.pageSize = take;
    //  this.skip = skip;
    //  this.pageSize = take;
    this.getAllMandatess();
    // this.state.skip = event.skip
    // this.loadItems();
  }

  public onPageChange(state: any): void {
    this.overviewPage.pageSize = state.take;
  }

  public getFrommServerData(): any {
    let selectedIds = [];

    if (this.mySelection.length > 0) {
      selectedIds = this.mySelection;
    }

    this.dashBoard.fetchExcelData(selectedIds).subscribe(records => {
      this.excel = [];
      if (records && records['dashBoardDataList'].length > 0) {
        records['dashBoardDataList'].forEach(row => {
          this.excel.push(row);
        });
        // this.excel.push(records['dashBoardDataList']);
        setTimeout(() => {
          this.excelService.exportAsExcelFile(this.excel, 'BD');
        }, 800)
      } else {
        this.toastr.warning('No records available to export', 'Excel export!');
        console.log('error');
      }
    });
    // return result;
  }

  openModal(options, type?) {
    this.isBulkMandate = false;
    this.productId = '';
    this.institutionId = '';
    if (type === 'delete') {
      if (this.mySelection && this.mySelection.length < 1) {
        return;
      }
    }
    if (type === 'bulkMandate') {
      this.isBulkMandate = true;
    }
    this.mandateSearch = type;
    this.singleModuleSearch.searchInstituteText = '';
    this.singleModuleSearch.searchProductTypeText = '';
    this.modalRef = this.modalService.show(options, { keyboard: false, ignoreBackdropClick: true });
    if (type === 'configureColumns') {
      this.checkColumnCount();
    }
  }

  selectionChange(dataItem) {
    console.log(dataItem);
    const dialog: DialogRef = this.dialogService.open({
      title: 'Please confirm',
      content: 'Are you sure?',
      actions: [
        { text: 'No' },
        { text: 'Yes', primary: true }
      ],
      width: 450,
      height: 200,
      minWidth: 250
    });

    dialog.result.subscribe((result) => {
      if (result instanceof DialogCloseResult) {
        console.log('close');
      } else {
        this.getAllMandatess();
        console.log('action', result);
        if (result.text === 'Yes') {
          console.log(dataItem);
          // if yes then service to save item
        }
      }

    });

  }

  saveFieldSelection() {
    this.loaderService.isLoading.next(true);
    console.log(this.stickyColumnDimensions);
    console.log(this.commonColumnDimensions)
    // console.log(JSON.stringify(dash));
    this.dashBoard.saveColumnFieldsSevice(this.stickyColumnDimensions, this.commonColumnDimensions).subscribe(res => {
      console.log(res);
      this.getColumnDisplay();
      this.loaderService.isLoading.next(false);
    }, err => {
      this.loaderService.isLoading.next(false);
    });
  }

  revertFieldSelection() {
    if (this.currentColumnSelection) {
      this.stickyColumnDimensions = this.currentColumnSelection['sticky'];
      this.commonColumnDimensions = this.currentColumnSelection['common'];
      this.columnDisplay();
    }
  }

  globalSearchFilter(searchBox) {
    this.loaderService.isLoading.next(true);
    this.dashBoard.globalHeaderSearch(searchBox).subscribe(result => {
      console.log(result);
      this.gridData = {
        data: result['dashBoardDataList'],
        total: result['allMandatesCount']
      };
      this.tabset.tabs[0].active = true;
      this.gridShow = 'all';
      this.loaderService.isLoading.next(false);
    }, err => {
      this.loaderService.isLoading.next(false);
    });
  }

  newDate(date) {
    return this.datePip.transform(date, 'dd/MM/yyyy HH:mm');
  }

  onSearchProductTypeChange = (text$: Observable<string>) => {
    return text$.pipe(
      debounceTime(400),
      distinctUntilChanged(),
      switchMap(term =>
        this.searchGetProduct(term).pipe(
          catchError(() => {
            return of([]);
          }))
      )
    );
  }

  searchGetProduct(term: string) { // return
    return new Observable(sub => {
      if (term.length > 0) {
        this.dashBoard.onProductAutoComplete({ 'productName': term })
          .subscribe(products => {
            let product: any;
            this.searchProductName = [];
            product = products.body;
            const linesArr = [];
            if (product.length === 0) {
              linesArr.push(['No Record for this search']);
            }
            for (let i = 0; i < product.length; i++) {
              if (product[i]) {
                this.searchProductName.push(product[i]);
                linesArr.push(product[i]['PRODUCTNAME']);
              }
            }
            sub.next(linesArr);
          });
      } else {
        const linesArr = [];
        sub.next(linesArr);
      }
    });
  }

  searchInstitutionName = (text$: Observable<string>) => {
    return text$.pipe(
      debounceTime(400),
      distinctUntilChanged(),
      switchMap(term =>
        this.searchGetInstitutionName(term).pipe(
          catchError(() => {
            return of([]);
          }))
      )
    );
  }

  searchGetInstitutionName(term) {
    return new Observable(sub => {
      if (term.length > 0) {
        this.dashBoard.onInstitutionAutoComplete({ 'instituteName': term })
          .subscribe(institution => {
            let ins: any;
            ins = institution.body;
            const linesArr = [];
            this.searchInstituteName = [];
            if (!ins) {
              linesArr.push(['No Record for this search']);
            }
            for (let i = 0; i < ins.length; i++) {
              if (ins[i]) {
                this.searchInstituteName.push(ins[i]);
                linesArr.push(ins[i]['INSTITUTIONNAME']);
              }
            }
            sub.next(linesArr);
          });
      } else {
        const linesArr = [];
        sub.next(linesArr);
      }
    });
  }

  selectedItem(item, searchedItem) {
    if (searchedItem === 'searchProductName') {
      this.singleModuleSearch.searchProductTypeText = '';
      let localItem = [];
      if (item !== 'No Record for this search') {
        for (let i = 0; i < this.searchProductName.length; i++) {
          if (this.searchProductName[i].PRODUCTNAME === item.item) {
            localItem = this.searchProductName[i];
            this.productId = this.searchProductName[i]['PRODUCTID'];
          }
        }
        console.log(localItem);
        this.singleModuleSearch.searchProductTypeText = localItem['PRODUCTNAME'];
      }
    }
    if (searchedItem === 'searchInstituteName') {
      this.singleModuleSearch.searchInstituteText = '';
      let localItem = [];
      if (item !== 'No Record for this search') {
        for (let i = 0; i < this.searchInstituteName.length; i++) {
          if (this.searchInstituteName[i].INSTITUTIONNAME === item.item) {
            localItem = this.searchInstituteName[i];
            this.institutionId = this.searchInstituteName[i]['INSTITUTIONID'];
          }
        }

        console.log(localItem);
        this.singleModuleSearch.searchInstituteText = localItem['INSTITUTIONNAME'];
      }
    }
    if (searchedItem === 'searchBillingComp') {
      this.singleModuleSearch.searchBillingCompany = '';
      let localItem = [];
      if (item !== 'No Record for this search') {
        for (let i = 0; i < this.searchBillingComp.length; i++) {
          if (this.searchBillingComp[i].company_name === item.item) {
            localItem = this.searchBillingComp[i];
          }
        }
        console.log(localItem);
        this.singleModuleSearch.searchBillingCompany = localItem['company_name'];
      }
    }
    if (searchedItem === 'searchBillingCompContact') {
      this.singleModuleSearch.searchBillingCompanyContact = '';
      let localItem = [];
      if (item !== 'No Record for this search') {
        for (let i = 0; i < this.searchBillingCompContact.length; i++) {
          if (this.searchBillingCompContact[i].contact_full_name === item.item) {
            localItem = this.searchBillingCompContact[i];
          }
        }

        console.log(localItem);
        this.singleModuleSearch.searchBillingCompanyContact = localItem['contact_full_name'];
      }
    }


    console.log(item);
  }

  searchBillingCompany = (text$: Observable<string>) => {
    return text$.pipe(
      debounceTime(400),
      distinctUntilChanged(),
      switchMap(term =>
        this.searchGetBillingCompany(term).pipe(
          catchError(() => {
            return of([]);
          }))
      )
    );
  }

  searchGetBillingCompany(term) {
    return new Observable(sub => {
      if (term.length > 0) {
        this.dashBoard.onBillingCompanyAutoComplete({ 'companyName': term })
          .subscribe(company => {
            let comp: any;
            this.searchBillingComp = [];
            comp = company.body;
            const linesArr = [];
            if (!comp) {
              linesArr.push(['No Record for this search']); //
            }
            for (let i = 0; i < comp.length; i++) {
              if (comp[i]) {
                this.searchBillingComp.push(comp[i]);
                linesArr.push(comp[i]['company_name']);
              }
            }
            sub.next(linesArr);
          });
      } else {
        const linesArr = [];
        sub.next(linesArr);
      }
    });
  }

  searchBillingCompanyContact = (text$: Observable<string>) => {
    return text$.pipe(
      debounceTime(400),
      distinctUntilChanged(),
      switchMap(term =>
        this.searchGetBillingCompanyContact(term).pipe(
          catchError(() => {
            return of([]);
          }))
      )
    );
  }

  searchGetBillingCompanyContact(term) {
    return new Observable(sub => {
      if (term.length > 0) {
        this.dashBoard.onBillingCompanyContactAutoComplete({ 'companyName': this.singleModuleSearch.searchBillingCompany, 'contactName': term })
          .subscribe(company => {
            this.searchBillingCompContact = [];
            let ccontact: any;
            ccontact = company.body;
            const linesArr = [];
            if (!ccontact) {
              linesArr.push(['No Record for this search']); // No Record for this search
            }
            for (let i = 0; i < ccontact.length; i++) {
              if (ccontact[i]) {
                this.searchBillingCompContact.push(ccontact[i])
                linesArr.push(ccontact[i]['contact_full_name']);
              }
            }
            sub.next(linesArr);
          });
      } else {
        const linesArr = [];
        sub.next(linesArr);
      }
    });
  }

  redirectToParentBonita() {
    this.dashBoard.getProcessIdToRedirectParent().subscribe(process => {
      console.log(process, '', process);
      if (process && process[0]) {
        window.location.href = '/bonita/portal/resource/process/SME%20Process/1.0/content/?id=' + process[0].id + '&locale=en&mode=app&productName=' + this.singleModuleSearch.searchProductTypeText + '&instituteName=' + this.singleModuleSearch.searchInstituteText + '&bacontact=' + this.singleModuleSearch.searchBillingCompanyContact + '&bacompnay=' + this.singleModuleSearch.searchBillingCompany + '&test=abcc';
      }
    });
  }

  proceedToDelete() {
    this.modalRef.hide();
    this.dashBoard.deleteMandates(this.mySelection).subscribe(res => {
      this.removeSelection();
      this.getMandatesCount();
      this.getAllMandatess();
      this.toastr.success('Deleted successfully!', 'Delete Records!');
    }, err => {
      this.toastr.error('Something went wrong! try again later', 'Delete Records!');
    })
  }

  removeSelection() {
    this.mySelection = [];
    this.selectAllState = 'unchecked';
  }

  validateMandate() {
    console.log(this.datastring);
    this.bulkUploadService.validateMandates(this.datastring).subscribe(response => {
      console.log(response);
      this.bulkUploadSharedData.setMandateData(response), () => { };
      this.modalRef.hide();
      this.router.navigate(['/bulkmandate']);
    });
  }

  uploadFile(ev) {

    this.datastring = {};
    this.usrData = {
      'Product Name': this.singleModuleSearch.searchProductTypeText,
      'Institution Name': this.singleModuleSearch.searchInstituteText,
      'Billing Company': this.singleModuleSearch.searchBillingCompany,
      'Billing Company Contact': this.singleModuleSearch.searchBillingCompanyContact
    };

    let workBook = null;
    let jsonData = null;
    const reader = new FileReader();
    const file = ev.target.files[0];
    let dataObj = [];
    reader.onload = (event) => {
      const data = reader.result;
      let datastr = [];
      workBook = XLSX.read(data, { type: 'binary' });
      jsonData = workBook.Sheets['Mandates'];
      let initial = XLSX.utils.sheet_to_json(jsonData, { raw: true, defval: null });
      if (initial.length > 0) {
        initial.forEach(function (row) {
          if (row['PRODUCT_TYPE'] && row['PRODUCT_CATEGORY']) {
            datastr.push(row);
          }
        });
      }
      dataObj = this.usrData;
      dataObj['mandates'] = datastr;
      this.datastring = JSON.stringify(dataObj);
      this.bulkUploadService.validateMandates(this.datastring).subscribe(response => {
        console.log(response);
        this.bulkUploadSharedData.setMandateData(response), () => { }
        this.modalRef.hide();
        this.router.navigate(['/bulkmandate']);
      });
    };
    reader.readAsBinaryString(file);
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

}
