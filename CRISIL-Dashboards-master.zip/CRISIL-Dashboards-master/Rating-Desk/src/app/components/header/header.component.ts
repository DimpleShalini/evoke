import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import { ToastrService } from 'ngx-toastr';
import { UserService, User } from '../../services/user.service';
import { DataService } from '../../services/share.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  currentUser: User = null;
  errorMessage = '';
  isLoading = true;
  searchbox = {
    searchFilter: '',
    searchWord: ''
  };
  showSelectBox: boolean;

  constructor(
    private userService: UserService,
    public cookieService: CookieService,
    private data: DataService,
    private router: Router,
    private toast: ToastrService) {
      this.router.events.subscribe( (event) => ( event instanceof NavigationEnd ) && this.handleRouteChange() );
  }

  ngOnInit() {
    this.userService.loggedInUser.subscribe(data => {
        this.currentUser = data ;
        this.isLoading = false;
    });
  }

  handleRouteChange = () => {
    this.searchbox.searchWord = '';
    this.searchbox.searchFilter = '';

    if (this.router.url === '/agenda') {
      this.showSelectBox = false;
    } else {
      this.showSelectBox = true;
    }
  }

  doSearch() {
    this.data.searchHeader(this.searchbox);
  }

  logout() {
    
  }
}
