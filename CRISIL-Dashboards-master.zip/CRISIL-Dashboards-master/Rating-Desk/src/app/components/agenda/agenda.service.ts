import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({ providedIn: 'root' })
export class AgendaService {
    constructor(private httpClient: HttpClient) { }

    getAgendaNo(type) {
        return this.httpClient.get<any>('/bonita/API/extension/smekpi?p=10&f=getmaxmeetingnumber&c=' + type);
    }

    addAgenda(data) {
        return this.httpClient.post<any>('/bonita/API/extension/smedashboard?f=insertAgenda', data);
    }

    getAgendaList(state) {
        const page = {
            page: state.skip / 10 + 1,
            pageSize: 10
        };
        return this.httpClient.post<any>('/bonita/API/extension/smedashboard?f=getAllAgendas',
            { page, filter: state.filter });
    }

}
