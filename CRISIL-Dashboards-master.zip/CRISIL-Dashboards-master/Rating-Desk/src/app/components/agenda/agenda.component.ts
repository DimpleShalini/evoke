import { Component, OnInit, TemplateRef, OnDestroy } from '@angular/core';

import { DataStateChangeEvent} from '@progress/kendo-angular-grid';
import { State } from '@progress/kendo-data-query';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { ToastrService } from 'ngx-toastr';
import { SubSink } from 'subsink';

import { CreateAgendaComponent } from './create-agenda.component';
import { AgendaService } from './agenda.service';
import { DataService } from 'src/app/services/share.service';
import { LoaderService } from 'src/app/loader.service';

@Component({
  selector: 'app-agenda',
  templateUrl: './agenda.component.html',
  styleUrls: ['./agenda.component.scss'],
})
export class AgendaComponent implements OnInit, OnDestroy {
  private subs = new SubSink();
  bsModalRef: BsModalRef;
  loading = false;
  config = { keyboard: false, ignoreBackdropClick: true };
  gridData: any = { data: [], total: 0 };
  public state: State = {
    skip: 0,
    take: 10,
    filter: {
      logic: 'and',
      filters: []
    }
  };

  constructor(
    private toastr: ToastrService,
    private modalService: BsModalService,
    private agService: AgendaService,
    private dataService: DataService,
    private loaderService: LoaderService) {

  }

  ngOnInit() {
    this.getAgendaList();
  }

  getAgendaList() {
    this.loaderService.isLoading.next(true);
    this.subs.sink = this.agService.getAgendaList(this.state).subscribe(
      res => {
        this.gridData.data = res.dashBoardDataList || [];
        this.gridData.total = res.totalCount || 0;
        this.loading = false;
      },
      error => {
        this.loaderService.isLoading.next(false);
        this.toastr.error('Error occurred. Please try again', 'Error!');
      }
    );
  }

  public dataStateChange(state: DataStateChangeEvent): void {
    this.state = state;
    this.getAgendaList();
  }

  createAgenda() {
    this.bsModalRef = this.modalService.show(CreateAgendaComponent, this.config);
    this.subs.sink = this.bsModalRef.content.action.subscribe((data) => {
      if (data) {
        this.getAgendaList();
      }
    });
  }

  assignAgenda(data) {
    this.dataService.changeAgendaNo(data.meeting_number);
  }

  ngOnDestroy() {
    this.subs.unsubscribe();
  }

}
