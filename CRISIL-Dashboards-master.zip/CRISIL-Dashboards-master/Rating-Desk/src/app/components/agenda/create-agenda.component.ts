import { Component, OnInit, Output, EventEmitter, OnDestroy } from '@angular/core';

import { BsModalRef } from 'ngx-bootstrap/modal';
import { ToastrService } from 'ngx-toastr';
import { AgendaService } from './agenda.service';
import { SubSink } from 'subsink';
import { IntlService } from '@progress/kendo-angular-intl';
import { LoaderService } from 'src/app/loader.service';

@Component({
    selector: 'create-agenda',
    templateUrl: 'create-agenda.component.html',
    styleUrls: ['./agenda.component.scss']
})

export class CreateAgendaComponent implements OnInit, OnDestroy {
    @Output() action = new EventEmitter();
    private subs = new SubSink();
    agType = '';
    loading = false;
    meetingNumber: any;
    allocationDate = new Date();

    constructor(
        public intl: IntlService,
        public modalRef: BsModalRef,
        private toastr: ToastrService,
        private agService: AgendaService,
        private loaderService: LoaderService) {

    }

    ngOnInit() { }

    typeChange() {
        this.loading = true;
        this.subs.sink = this.agService.getAgendaNo(this.agType).subscribe(
            data => {
                this.loading = false;
                this.meetingNumber = data.agendaNumber;
            },
            error => {
                this.toastr.error('Failed to get meeting number', 'Error');
            }
        );
    }

    onSubmit() {
        const obj = {
            meetingNumber: this.meetingNumber,
            allocationDate: this.allocationDate,
            agendaDate: this.intl.formatDate(this.allocationDate, 'ddMMMyyyy')
        };
        this.loaderService.isLoading.next(true);

        this.subs.sink = this.agService.addAgenda(obj).subscribe(
            data => {
                this.loaderService.isLoading.next(false);
                if (!data) {
                    this.toastr.warning(this.meetingNumber + ' is already used, generating new number please wait', 'Warning');
                    this.typeChange();
                    return;
                }
                this.toastr.success('You have submitted successfully', 'Success');
                this.action.emit(true); // emit only when successfully added
                this.modalRef.hide();
            },
            error => {
                this.toastr.error('Failed to add agenda number', 'Error');
            }
        );
    }

    ngOnDestroy() {
        this.subs.unsubscribe();
    }

}
