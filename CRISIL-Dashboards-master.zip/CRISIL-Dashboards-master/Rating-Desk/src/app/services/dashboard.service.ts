import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { SettingsService } from './settings.service';

@Injectable()
export class DashboardService {
  private API_ALL_MANDATES_URL = '/extension/smekpi';
  private API_GET_COLUMN_FIELDS = '/extension/smekpi';
  private API_SET_COLUMN_FIELDS = '/extension/smedashboard';
  private API_GET_AUTO_PRODUCT = '/extension/getMasterData';
  private API_GET_COLUMN_DATA = '/extension/smedashboard?f=getreviewermandates';
  private API_GET_MANDATES_URL_FILTERS = '/extension/smedashboard?f=getreviewermandatesbystatus';
  private API_GET_EXCEL_MANDATES = '/extension/smedashboard?f=getreviewermandatesforexcel';
  private API_VALIDATE_MANDATE_FIELDS = '/extension/validateMandatesData';
  private API_CREATE_MANDATES = '/extension/createMandates';

  constructor(
    private http: HttpClient,
    private settingsService: SettingsService
  ) { }


  getAllMandatesWithFilters(filter?, page?, sort?) {
    //    POST /api/v1/purchaseorder
    return this.http.post<any>(this.settingsService.getBonitaApiBaseUrl() + this.API_GET_COLUMN_DATA, {
      filter: filter,
      page: page,
      sort: sort
    });
  }

  deleteMandates(rec) {
    return this.http.get<any>(this.settingsService.getBonitaApiBaseUrl() +
           this.API_ALL_MANDATES_URL + '?c=0&p=10&f=deletemandates&ids=' + rec.join());
  }

  onProductAutoComplete(obj) {
    return this.http.post<any>(
      this.settingsService.getBonitaApiBaseUrl() +
      this.API_GET_AUTO_PRODUCT + '?f=product',
      obj,
      { observe: 'response' }
    );
  }

  onInstitutionAutoComplete(obj) {
    return this.http.post<any>(
      this.settingsService.getBonitaApiBaseUrl() +
      this.API_GET_AUTO_PRODUCT + '?f=institution',
      obj,
      { observe: 'response' }
    );
  }

  onBillingCompanyAutoComplete(obj) {
    return this.http.post<any>(
      this.settingsService.getBonitaApiBaseUrl() +
      this.API_GET_AUTO_PRODUCT + '?f=bacompany',
      obj,
      { observe: 'response' }
    );
  }

  onBillingCompanyContactAutoComplete(obj) {
    return this.http.post<any>(
      this.settingsService.getBonitaApiBaseUrl() +
      this.API_GET_AUTO_PRODUCT + '?f=bacompanycontact',
      obj,
      { observe: 'response' }
    );
  }

  getColumnFieldService() {
    return this.http.get(
      this.settingsService.getBonitaApiBaseUrl() +
      this.API_GET_COLUMN_FIELDS +
      '?c=0&p=10&f=getdashboardfields'
    );
  }

  saveColumnFieldsSevice(leftColumn, rightColumn) {
    return this.http.post<any>(
      this.settingsService.getBonitaApiBaseUrl() +
      this.API_SET_COLUMN_FIELDS +
      '?c=0&p=10&f=saveconfiguration',
      { dashboardFieldMenu: leftColumn, rightDashboardFieldMenu: rightColumn },
      { observe: 'response' }
    );
  }

  getMadatesCount() {
    return this.http.get<any>(this.settingsService.getBonitaApiBaseUrl() + this.API_ALL_MANDATES_URL + '?c=0&p=0&f=getOverAllCountsForReviewer');
  }

  getMandatesByFilter(filter?, page?, mandateStatus?) {
    return this.http.post<any>(this.settingsService.getBonitaApiBaseUrl() + this.API_GET_MANDATES_URL_FILTERS, {
      filter,
      page,
      mandateStatus: mandateStatus
    });
  }

  getProcessIdToRedirectParent() {
    return this.http.get('/bonita/API/bpm/process?f=name=SME Process&p=0&c=1&o=version%20desc&f=activationState=ENABLED');
  }

  fetchExcelData(data) {
    if (data.length > 0) {
      return this.http.post(this.settingsService.getBonitaApiBaseUrl() + this.API_GET_EXCEL_MANDATES, { requestids: data.join() });
    } else {
      return this.http.post(this.settingsService.getBonitaApiBaseUrl() + this.API_GET_EXCEL_MANDATES, {});
    }
  }

  globalHeaderSearch(globalSearch) {
    return this.http.post<any>(
      this.settingsService.getBonitaApiBaseUrl() + this.API_SET_COLUMN_FIELDS + '?f=getreviewermandatesforglobalsearch',
      {
        filter: {
          filters: [
            {
              filters: [
                {
                  field: '',
                  operator: '',
                  value: ''
                }
              ]
            },
          ],
          logic: 'and'
        },
        page: {
          page: 1,
          pageSize: 10
        },
        sort: {
          dir: '',
          field: ''
        },
        columnName: globalSearch.searchFilter ? globalSearch.searchFilter : '',
        searchString: globalSearch.searchWord
      },
      { observe: 'response' }
    );
  }


  getDownloadExcelFile(obj) {
    return this.http.post<any>('http://dev-bonita.smefirst.com:8080/accesssme/downloadBulkUploadTemplates', obj);
  }

  bulkUploadValidation(obj) {
    return this.http.post<any>(
      this.settingsService.getBonitaApiBaseUrl() + this.API_VALIDATE_MANDATE_FIELDS, obj);
  }
  createBulkMandates(obj) {
    return this.http.post<any>(
      this.settingsService.getBonitaApiBaseUrl() + this.API_CREATE_MANDATES,
      obj);
  }

}
