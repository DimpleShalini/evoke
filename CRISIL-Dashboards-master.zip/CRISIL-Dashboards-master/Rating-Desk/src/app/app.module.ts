import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HTTP_INTERCEPTORS, HttpClientModule} from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AngularFontAwesomeModule } from 'angular-font-awesome';

import { TabsModule } from 'ngx-bootstrap/tabs';
import { ModalModule } from 'ngx-bootstrap/modal';
import { CookieService } from 'ngx-cookie-service';
import { ToastrModule } from 'ngx-toastr';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { DialogsModule } from '@progress/kendo-angular-dialog';
import { DateInputsModule } from '@progress/kendo-angular-dateinputs';
import { GridModule, ExcelModule  } from '@progress/kendo-angular-grid';

import { AppComponent } from './app.component';
import { LoaderComponent} from './components/loader/loader.component';
import { LoaderService } from './loader.service';
import { LoaderInterceptor } from './loader.interceptor';
import { HeaderComponent } from './components/header/header.component';
import { UserService } from './services/user.service';
import { SettingsService } from './services/settings.service';
import { LandingComponent } from './components/landing/landing.component';
import { DashboardService } from './services/dashboard.service';
import { MultiSelectModule, DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { MultiCheckFilterComponent } from './components/landing/my-dropdown-filter';
import { BulkuploadService } from './services/bulkupload.service';
import { BulkuploadSharedData } from './services/bulkUpload.sharedData.service';
import { DataService } from './services/share.service';
import { AgendaComponent } from './components/agenda/agenda.component';
import { CreateAgendaComponent } from './components/agenda/create-agenda.component';

const routes: Routes = [
   { path: 'agenda', component: AgendaComponent },
   { path: 'landing/:agno', component: LandingComponent },
   { path: '', redirectTo: 'agenda', pathMatch: 'full' },
   { path: '**', redirectTo: 'landing' }
 ];

@NgModule({
  declarations: [
    AppComponent,
    LoaderComponent,
    HeaderComponent,
    LandingComponent,
    MultiCheckFilterComponent,
    AgendaComponent,
    CreateAgendaComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(routes, { useHash: true }),
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    NgbModule,
    TabsModule.forRoot(),
    ModalModule.forRoot(),
    AngularFontAwesomeModule,
    HttpClientModule,
    BrowserAnimationsModule,
    GridModule,
    ExcelModule,
    MultiSelectModule,
    DropDownsModule,
    ToastrModule.forRoot({
      timeOut: 4000,
      positionClass: 'toast-top-right',
      preventDuplicates: true,
    }),
    DialogsModule,
    DateInputsModule
  ],
  providers: [
    LoaderService,
    UserService,
    SettingsService,
    DashboardService,
    CookieService,
    BulkuploadService,
    BulkuploadSharedData,
    DataService,
    { provide: HTTP_INTERCEPTORS, useClass: LoaderInterceptor, multi: true }
  ],
  bootstrap: [AppComponent],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
  entryComponents: [CreateAgendaComponent]
})
export class AppModule { }
