(function () {
  try {
    return angular.module('bonitasoft.ui.widgets');
  } catch(e) {
    return angular.module('bonitasoft.ui.widgets', []);
  }
})().directive('customTableWidgit2', function() {
    return {
      controllerAs: 'ctrl',
      controller: /**
 * The controller is a JavaScript function that augments the AngularJS scope and exposes functions that can be used in the custom widget template
 * 
 * Custom widget properties defined on the right can be used as variables in a controller with $scope.properties
 * To use AngularJS standard services, you must declare them in the main function arguments.
 * 
 * You can leave the controller empty if you do not need it.
 */
function ($scope,$http,$location) {
    var white = 'white';
    
     $scope.redMarkURL = "https://github.com/Evoke-Technologies-Pvt-Ltd/AmerenBPM/blob/master/Red%20Line.gif";
     $scope.greenMarkURL = "https://github.com/Evoke-Technologies-Pvt-Ltd/AmerenBPM/blob/master/Green Checkmark.gif";
    
    // add a new variable in AngularJS scope. It'll be usable in the template directly with {{ backgroudColor }} 
    $scope.backgroudColor = white;
    
    var protocol = $location.protocol();
    var host =  $location.host();
    var port =  $location.port();
    console.log('host '+host);
    console.log('port '+port);
    console.log('protocol'+protocol);
    
   // $scope.tableData = $scope.properties.tableData;
    
    //console.log(url);  
    
   /*$http.get($scope.properties.userInfoUrl)
    .then(function(res) {
              var url = $scope.properties.ajaxUrl+"&f=requestorID="+res.data.user_id;
              console.log(url);
              $http.get(url)
                .then(function(response) {
                 $scope.records = response.data;
              });
    });*/
    console.log('$scope.properties.values'+$scope.properties.values);
     $scope.records = $scope.properties.values;
    
    
    $scope.aproveImg="./assets/img/Green Checkmark.gif";
    $scope.penddingImg="./assets/img/Red Line.gif";
    
    // define a function to be used in template with ctrl.toggleBackgroundColor()
    this.toggleBackgroundColor = function() {
        if ($scope.backgroudColor === white) {
           // use the custom widget property backgroudColor with $scope.properties.backgroudColor
            $scope.backgroudColor = $scope.properties.background;
        } else {
            $scope.backgroudColor = white;
        }
    };
    $scope.column = 'requestType';
    // sort ordering (Ascending or Descending). Set true for desending
 $scope.reverse = false; 
 
 // called on header click
 $scope.sortColumn = function(col){
  $scope.column = col;
  if($scope.reverse){
   $scope.reverse = false;
   $scope.reverseclass = 'arrow-up';
  }else{
   $scope.reverse = true;
   $scope.reverseclass = 'arrow-down';
  }
 };
 
 // remove and change class
 $scope.sortClass = function(col){
  if($scope.column == col ){
   if($scope.reverse){
    return 'arrow-down'; 
   }else{
    return 'arrow-up';
   }
  }else{
   return '';
  }
 } 
 
 $scope.totalItems = $scope.records.length;
  $scope.currentPage = 1;
  $scope.numPerPage = 5;
  
  $scope.paginate = function(value) {
    var begin, end, index;
    begin = ($scope.currentPage - 1) * $scope.numPerPage;
    end = begin + $scope.numPerPage;
    index = $scope.records.indexOf(value);
    return (begin <= index && index < end);
  };
    
    
    $scope.setPage = function () {
        $scope.currentPage = this.n;
    };
    
   
},
      template: '<!-- The custom widget template is defined here\n   - You can use standard HTML tags and AngularJS built-in directives, scope and interpolation system\n   - Custom widget properties defined on the right can be used as variables in a templates with properties.newProperty\n   - Functions exposed in the controller can be used with ctrl.newFunction()\n   - You can use the \'environment\' property injected in the scope when inside the Editor whiteboard. It allows to define a mockup\n     of the Custom Widget to be displayed in the whiteboard only. By default the widget is represented by an auto-generated icon\n     and its name (See the <span> below).\n-->\n \n\n<!--<div style="color: {{ properties.color }}; background-color: {{ backgroudColor }}" ng-click="ctrl.toggleBackgroundColor()">\n    Value is:  <i>{{ properties.value }}</i>. Click me to toggle background color\n</div>-->\n\n<div class="my_table">\n  <table class="table">\n    <thead>\n      <tr class="active">\n        <th ng-click=\'sortColumn("requestType")\' ng-class=\'sortClass("requestType")\'>Request Type</th>\n        <!--<th>Requestor ID</th>-->\n        <th ng-click=\'sortColumn("requestorName")\' ng-class=\'sortClass("requestorName")\'>Requestor Name</th>\n        <th ng-click=\'sortColumn("startTime")\' ng-class=\'sortClass("startTime")\'>Start Time</th>\n        <th ng-click=\'sortColumn("emailId")\' ng-class=\'sortClass("emailId")\'>Email Id</th>\n        <th ng-click=\'sortColumn("requestStatus")\' ng-class=\'sortClass("requestStatus")\'>Request Status</th> \n        <th>Request Enrollment</th>\n        <th>Supervisor Approval</th>\n        <th>Manager Approval</th>\n        <th>Outlook Setup</th>\n        <th>Payroll Setup</th>\n        <th>Enrollment Complete</th>\n        <th>Requested Stipend</th>\n      </tr>\n    </thead>\n    \n     \n    \n    <tbody>\n      <tr ng-repeat="record in records|orderBy:column:reverse | filter : paginate">\n        <td>{{record.requestType}}</td>\n        <!--<td>{{record.requestorID}}</td>-->\n        <td>{{record.requestorName}}</td>\n        <td>{{record.startTime | date : "MMM d, y h:mm:ss a"}}</td> \n        <td>{{record.emailId}}</td>\n        <td>{{record.requestStatus}}</td>\n        <td>\n            <span ng-if="record.requestEnrollment == true">\n                <img src="widgets/customTableWidgit2/assets/img/Green Checkmark.gif"/>\n            </span>\n            <span ng-if="record.requestEnrollment == false">\n                <img ng-src="widgets/customTableWidgit2/assets/img/Red Line.gif"/>\n            </span>\n        </td>\n        <td>\n            <span>\n                <img ng-src="{{record.status > 1 ? \'widgets/customTableWidgit2/assets/img/Green Checkmark.gif\' : \'widgets/customTableWidgit2/assets/img/Red Line.gif\'}}" />\n            </span>\n        </td>\n        <td>\n            <span>\n              <img ng-src="{{record.reimbursement === \'false\'  ? \'widgets/customTableWidgit2/assets/img/Red Line.gif\' : record.status > 2 ? \'widgets/customTableWidgit2/assets/img/Green Checkmark.gif\' : \'widgets/customTableWidgit2/assets/img/Red Line.gif\' }}" />\n            </span>\n           \n        </td>\n        <td>\n             <span>\n               <img ng-src="{{record.status > 3 ? \'widgets/customTableWidgit2/assets/img/Green Checkmark.gif\' : \'widgets/customTableWidgit2/assets/img/Red Line.gif\'}}" />\n            </span>\n        </td>\n        <td>\n            <span>\n                <img ng-src="{{record.reimbursement === \'false\'  ? \'widgets/customTableWidgit2/assets/img/Red Line.gif\' : record.status > 4 ? \'widgets/customTableWidgit2/assets/img/Green Checkmark.gif\' : \'widgets/customTableWidgit2/assets/img/Red Line.gif\' }}" />\n            </span>\n        </td>\n        <td> \n           <span>\n                <img ng-src="{{record.status > 5 ? \'widgets/customTableWidgit2/assets/img/Green Checkmark.gif\' : \'widgets/customTableWidgit2/assets/img/Red Line.gif\'}}" />\n            </span>\n        </td>\n        <td>\n             <span ng-if="record.requestedStipend == true">\n                True\n            </span>\n            <span ng-if="record.requestedStipend == false">\n                False\n            </span>\n        \n        </td>\n      </tr>\n    </tbody>\n    \n  <tfoot>\n       <tr>\n           <td colspan="12">\n               <div class="mypagination"> \n                <pagination total-items="totalItems" ng-model="currentPage"\n                    max-size="50" boundary-links="true"\n                     items-per-page="numPerPage" class="pagination-sm">\n                 </pagination>\n             </div>\n            </td>\n      </tr>\n  </tfoot>\n                \n    \n  </table>\n \n</div>'
    };
  });
