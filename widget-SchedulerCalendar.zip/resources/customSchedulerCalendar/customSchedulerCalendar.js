(function () {
  try {
    return angular.module('bonitasoft.ui.widgets');
  } catch(e) {
    return angular.module('bonitasoft.ui.widgets', []);
  }
})().directive('customSchedulerCalendar', function() {
    return {
      controllerAs: 'ctrl',
      controller: /**
 * The controller is a JavaScript function that augments the AngularJS scope and exposes functions that can be used in the custom widget template
 * 
 * Custom widget properties defined on the right can be used as variables in a controller with $scope.properties
 * To use AngularJS standard services, you must declare them in the main function arguments.
 * 
 * You can leave the controller empty if you do not need it.
 */
function ($scope, $http, uiCalendarConfig,$modal,$templateCache,$log) {
    
 
   //$scope.SelectedEvent = null;
    var isFirstTime = true;
    $scope.events = [];
        $scope.eventSources = [$scope.events];
        $scope.SelectedEvent={};
$scope.vehicle ={};
 
  $http.get("http://localhost:9090/bonita/API/bdm/businessData/com.demo.company.AmerenShuttleScheduler?q=find&p=0&c=10")
                .success(function(data, status, headers, config){
                    console.log("SUCCESSSSSSS data", data);
                     console.log("SUCCESSSSSSS data 33333333333", data.length);
                    var sampledata = JSON.stringify(data);
                   
        console.log("SUCCESSSSSSS sampledata length ", sampledata.length);
       
  
 
    $scope.events.slice(0, $scope.events.length);
       for(var i=0;i<data.length;i++)
         {
             var value =data[i]; 
            var dt  = new Date(value.startDate);
            console.log('value.startDate zzzzzzzzzzzzzzzzz '+value.startDate);
            console.log('value.startDate zzzzzzzzzzzzzzzzz '+dt);
            var colorDisplay='';
            value.startTime = dt.getHours() + " :  " + dt.getMinutes() +" " + (dt.getHours() >= 12 ? 'pm' : 'am');
           if( parseInt(value.totalPassengersAlloted) < parseInt(value.capacity) ){
               if(angular.equals(value.isApproved, "approved")){
                   colorDisplay="green";
               }else{
                   colorDisplay="blue";
               }
               
           }else{
               colorDisplay = 'yellow';
           }
           // console.log('111111111111111111111');
            $scope.events.push({
                id: value.persistenceId,
                title: value.startTime+" "+ value.vehicleName,
                start: new Date(value.startDate),
                end: new Date(value.returnDate),
                allDay : false,
                color:colorDisplay,
                stick: true
            });
        }
        console.log('2222222222222222222222222222222222');
       console.log("events "+JSON.stringify($scope.eventSources));
        
    //configure calendar
    $scope.uiConfig = {
        calendar: {
            height: 450,
            editable: true,
            displayEventTime: false,
            header: {
                left: 'month basicWeek basicDay',
                center: 'title',
                right:'today prev,next'
            },
            eventClick: function (event) {
               console.log('9999999999999999999999999999999999');
                var vehicleId = event.id;
                console.log('vechilce id '+vehicleId);
                for(var j=0;j<data.length;j++){
                    var v = data[j];
                    if( angular.equals(vehicleId,v.persistenceId) ){
                       $scope.SelectedEvent = v; 
                       break;
                    }
                }
                 console.log('sssssssssssssssssssssssssssss'+JSON.stringify($scope.SelectedEvent));
               // console.log('selected event '+$scope.SelectedEvent);
        $modal.open({
            templateUrl: 'modalReservationContent.html' , // loads the template
            backdrop: true, // setting backdrop allows us to close the modal window on clicking outside the modal window
            windowClass: 'modal', // windowClass - additional CSS class(es) to be added to a modal window template
            controller: function ($scope, $modalInstance, $log, SelectedEvent) {
                $scope.vehicle =SelectedEvent;
                console.log('$scope.vehicle  '+ JSON.stringify($scope.vehicle) );
                $scope.submit = function () {
                    $log.log('Submiting user info.'); // kinda console logs this statement
                    $log.log(vehicle); 
                    $modalInstance.dismiss('cancel'); // dismiss(reason) - a method that can be used to dismiss a modal, passing a reason
                }
                $scope.cancel = function () {
                    $modalInstance.dismiss('cancel'); 
                };
            },
            resolve: {
                SelectedEvent: function () {
                    return  $scope.SelectedEvent;
                }
            }
        });//end of modal.open
            },
            eventAfterAllRender: function () {
                console.log('ggggggggggggggggggggg'+$scope.events.length);
                if ($scope.events.length > 0 && isFirstTime) {
                    //Focus first event
                    uiCalendarConfig.calendars.myCalendar.fullCalendar('gotoDate', $scope.events[0].start);
                    isFirstTime = false;
                }
            }
        }
    };
                }).error(function(data, status, headers, config){
        console.log("FAILEDDDDDDD");
      
     
                });
   
   
 
    
},
      template: '<!-- The custom widget template is defined here\n   - You can use standard HTML tags and AngularJS built-in directives, scope and interpolation system\n   - Custom widget properties defined on the right can be used as variables in a templates with properties.newProperty\n   - Functions exposed in the controller can be used with ctrl.newFunction()\n   - You can use the \'environment\' property injected in the scope when inside the Editor whiteboard. It allows to define a mockup\n     of the Custom Widget to be displayed in the whiteboard only. By default the widget is represented by an auto-generated icon\n     and its name (See the <span> below).\n-->\n <div style="margin-left:150px;">\n<script type="text/ng-template" id="modalReservationContent.html">\n        <div class="modal-header">\n            <h3>  Shuttle Request </h3>\n        </div>\n        <form ng-submit="submit()">\n          <div class="modal-body">\n            Name : {{ vehicle.vehicleName }} </br>\n            Start: {{ vehicle.startDate }}</br>\n            End: {{vehicle.endDate}}</br>\n            Destination :  {{ vehicle.destination }} </br>\n            Two-Way Trip : {{ vehicle.twoWayTrip }} </br>\n            {{ vehicle.wheelchairAccessibility}}  Require Wheelchair Accessibility </br>\n            {{ vehicle.totalPassengersAlloted }}  Passengers </br>\n            Pending Approval {{ vehicle.isApproved}} ({{vehicle.startDate}})   \n          </div>\n          <div class="modal-footer">\n              <button class="btn btn-warning" ng-click="cancel()">Cancel Reservation</button>\n              <input type="submit" class="btn primary-btn" value="Edit Reservation" />\n          </div>\n        </form>\n    </script>\n\n</div>\n<div>\n    <div class="row">\n        <div class="col-md-12">\n            <div id="calendar" ui-calendar="uiConfig.calendar" ng-model="eventSources" calendar="myCalendar"></div>\n        </div>\n    </div>\n</div>'
    };
  });
