(function () {
  try {
    return angular.module('bonitasoft.ui.widgets');
  } catch(e) {
    return angular.module('bonitasoft.ui.widgets', []);
  }
})().directive('customSolarBearTable', function() {
    return {
      controllerAs: 'ctrl',
      controller: /**
 * The controller is a JavaScript function that augments the AngularJS scope and exposes functions that can be used in the custom widget template
 * 
 * Custom widget properties defined on the right can be used as variables in a controller with $scope.properties
 * To use AngularJS standard services, you must declare them in the main function arguments.
 * 
 * You can leave the controller empty if you do not need it.
 * 
 * 
 */
function($scope, $templateCache, $interval, $q, $rootScope, $document, uiGridEditConstants, uiGridConstants) {

    $templateCache.put('ui-grid/selectionRowHeaderButtons',
        "<div class=\"ui-grid-selection-row-header-buttons \" ng-class=\"{'ui-grid-row-selected': row.isSelected}\" ><input style=\"margin: 0; vertical-align: middle\" type=\"checkbox\" ng-model=\"row.isSelected\" ng-click=\"row.isSelected=!row.isSelected;selectButtonClick(row, $event)\">&nbsp;</div>"
    );


    $templateCache.put('ui-grid/selectionSelectAllButtons',
        "<div class=\"ui-grid-selection-row-header-buttons \" ng-class=\"{'ui-grid-all-selected': grid.selection.selectAll}\" ng-if=\"grid.options.enableSelectAll\"><input style=\"margin: 0; vertical-align: middle\" type=\"checkbox\" ng-model=\"grid.selection.selectAll\" ng-click=\"grid.selection.selectAll=!grid.selection.selectAll;headerButtonClick($event)\"></div>"
    );


    $scope.SelectedRow = [];

    $scope.gridOptions = {
        enableSorting: true,
        enableFiltering: true,
        enableRowSelection: true,
        multiSelect: false,
        enableSelectAll: true,
        enableColumnMenus: false,
        enableCellEditOnFocus: true,
        enableCellEdit: true,
        paginationPageSizes: [25, 50, 75],
        paginationPageSize: 25,
        columnDefs: [{
                field: 'plant',
                enableCellEdit: true,
                cellTemplate: '<div  ng-if="!row.entity.editrow">{{COL_FIELD}}</div><div ng-if="row.entity.editrow"><input type="text" style="height:30px" ng-model="MODEL_COL_FIELD"</div>'
            },
            {
                field: 'reqDate',
                enableCellEdit: true,
                cellTemplate: '<div  ng-if="!row.entity.editrow">{{COL_FIELD}}</div><div ng-if="row.entity.editrow"><input type="text" style="height:30px" ng-model="MODEL_COL_FIELD"</div>'
            },
            {
                field: 'purchReq',
                enableCellEdit: true,
                cellTemplate: '<div width : "*"  ng-if="!row.entity.editrow">{{COL_FIELD}}</div><div ng-if="row.entity.editrow"><input type="text" style="height:30px" ng-model="MODEL_COL_FIELD"</div>'
            },
            {
                field: 'Chngd',
                enableCellEdit: true,
                cellTemplate: '<div  ng-if="!row.entity.editrow">{{COL_FIELD}}</div><div ng-if="row.entity.editrow"><input type="text" style="height:30px" ng-model="MODEL_COL_FIELD"</div>'
            },
            {
                field: 'releaseDate',
                enableCellEdit: true,
                cellTemplate: '<div width : "*"  ng-if="!row.entity.editrow">{{COL_FIELD}}</div><div ng-if="row.entity.editrow"><input type="text" style="height:30px" ng-model="MODEL_COL_FIELD"</div>'
            },
            {
                field: 'matlGroup',
                enableCellEdit: true,
                cellTemplate: '<div  ng-if="!row.entity.editrow">{{COL_FIELD}}</div><div ng-if="row.entity.editrow"><input type="text" style="height:30px" ng-model="MODEL_COL_FIELD"</div>'
            },
            {
                field: 'shortText',
                width: "260",
                enableCellEdit: true,
                cellTemplate: '<div  ng-if="!row.entity.editrow">{{COL_FIELD}}</div><div ng-if="row.entity.editrow"><input type="text" style="height:30px" ng-model="MODEL_COL_FIELD"</div>'
            },
            {
                field: 'Quantity',
                enableCellEdit: true,
                cellTemplate: '<div  ng-if="!row.entity.editrow">{{COL_FIELD}}</div><div ng-if="row.entity.editrow"><input type="text" style="height:30px" ng-model="MODEL_COL_FIELD"</div>'
            },
            {
                name: 'priority',
                filed: 'priority',
                displayName: 'Priority',
                editableCellTemplate: 'ui-grid/dropdownEditor',
                width: '*',
                editDropdownIdLabel: 'id',
                editDropdownValueLabel: 'priority',
                editDropdownFilter: 'translate',
                editDropdownOptionsArray: [{
                        id: 'high',
                        priority: 'high'
                    },
                    {
                        id: 'medium',
                        priority: 'medium'
                    },
                    {
                        id: 'low',
                        priority: 'low'
                    }
                ]
            },
            {
                name: 'vendors',
                filed: 'vendors',
                displayName: 'Vendors',
                width: '*',
                editableCellTemplate: 'ui-grid/dropdownEditor',
                editDropdownRowEntityOptionsArrayPath: 'vendorList.options',
                editDropdownIdLabel: 'value'
            }/*,
            {
                name: 'Submit',
                enableFiltering: false,
                enableSorting: false,
                headerCellTemplate: '<div></div>',
                cellTemplate: '<div> <button ng-disabled="!row.isSelected" class="btn primary" ng-click="grid.appScope.submit(row.entity)">Submit</button> </div>'
            }*/

        ],
        onRegisterApi: function(gridApi) {
            $scope.gridApi = gridApi;
            gridApi.selection.on.rowSelectionChanged($scope, function(row) {
                var msg = 'row selected ' + row.isSelected;
                console.log('msg', msg);
                console.log('selected row ', row.entity.plant);
                 $scope.SelectedRow =     { 
                                 "plant": row.entity.plant,
                                "reqDate": row.entity.reqDate,
                                "purchReq": row.entity.purchReq,
                                "Chngd": row.entity.Chngd,
                                "releaseDate": row.entity.releaseDate,
                                "matlGroup": row.entity.matlGroup,
                                "shortText": row.entity.shortText,
                                "Quantity": row.entity.Quantity,
                                "priority" : row.entity.priority,
                    			"vendorList" : row.entity.vendors
                 };
                console.log('222222222222 ',$scope.SelectedRow);
                $scope.properties.SelectedRow =  $scope.SelectedRow;
            });
        }
    };

    $scope.vendorName = ['v1', 'v2', 'v3'];
    $scope.gridOptions.data = $scope.properties.EmployeeList;

    $scope.submit = function(row) {
        console.log('submit.....', row);
        console.log('submit.....', row.plant);
    };

},
      template: ' <!-- The custom widget template is defined here\n   - You can use standard HTML tags and AngularJS built-in directives, scope and interpolation system\n   - Custom widget properties defined on the right can be used as variables in a templates with properties.newProperty\n   - Functions exposed in the controller can be used with ctrl.newFunction()\n   - You can use the \'environment\' property injected in the scope when inside the Editor whiteboard. It allows to define a mockup\n     of the Custom Widget to be displayed in the whiteboard only. By default the widget is represented by an auto-generated icon\n     and its name (See the <span> below).\n-->\n \n\n<div id="GridCustomId" ui-grid="gridOptions" ui-grid-edit ui-grid-selection ui-grid-cellnav   ui-grid-pagination  class="myGrid" ></div>\n        \n       \n'
    };
  });
